import { Router } from "express";
import { db, roomsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { insertRoomSchema, updateRoomSchema } from "@workspace/db";
import { logActivity, actorFromRequest } from "./activityLogs.js";

const router = Router();

function tid(req: import("express").Request): number | null {
  return ((req as any).sessionUser as any)?.tenantId ?? null;
}

function fmt(r: typeof roomsTable.$inferSelect) {
  return { ...r, pricePerNight: Number(r.pricePerNight), createdAt: r.createdAt.toISOString() };
}

router.get("/rooms", async (req, res) => {
  const tenantId = tid(req);
  const rooms = await db
    .select()
    .from(roomsTable)
    .where(tenantId !== null ? eq(roomsTable.tenantId, tenantId) : undefined)
    .orderBy(roomsTable.name);
  res.json(rooms.map(fmt));
});

router.post("/rooms", async (req, res) => {
  const tenantId = tid(req) ?? 1;
  const parsed = insertRoomSchema.safeParse({ ...req.body, tenantId });
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [room] = await db.insert(roomsTable).values(parsed.data).returning();
  const actor = actorFromRequest(req);
  logActivity({ ...actor, tenantId, action: "room.created", entityType: "room", entityId: room.id, entityLabel: room.name, propertyId: room.propertyId ?? undefined });
  res.status(201).json(fmt(room));
});

router.post("/rooms/bulk", async (req, res) => {
  const tenantId = tid(req) ?? 1;
  const { propertyId, prefix, startNumber, endNumber, type, status, capacity, pricePerNight } = req.body;
  if (!propertyId || !prefix || startNumber == null || endNumber == null || !type || !status) {
    res.status(400).json({ error: "Missing required fields" }); return;
  }
  const start = parseInt(startNumber, 10);
  const end = parseInt(endNumber, 10);
  if (isNaN(start) || isNaN(end) || end < start || (end - start + 1) > 100) {
    res.status(400).json({ error: "Range must be valid and ≤ 100 units" }); return;
  }
  const values = [];
  for (let i = start; i <= end; i++) {
    values.push({
      tenantId,
      propertyId: parseInt(propertyId, 10),
      name: `${prefix}${i}`,
      type,
      status,
      capacity: capacity ? parseInt(capacity, 10) : 2,
      pricePerNight: pricePerNight ? String(pricePerNight) : "0",
    });
  }
  const rooms = await db.insert(roomsTable).values(values).returning();
  res.status(201).json(rooms.map(fmt));
});

router.get("/rooms/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const tenantId = tid(req);
  const conds = [eq(roomsTable.id, id)];
  if (tenantId !== null) conds.push(eq(roomsTable.tenantId, tenantId));
  const [room] = await db.select().from(roomsTable).where(and(...conds));
  if (!room) { res.status(404).json({ error: "Room not found" }); return; }
  res.json(fmt(room));
});

router.patch("/rooms/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const tenantId = tid(req);
  const parsed = updateRoomSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const conds = [eq(roomsTable.id, id)];
  if (tenantId !== null) conds.push(eq(roomsTable.tenantId, tenantId));
  const [room] = await db.update(roomsTable).set(parsed.data).where(and(...conds)).returning();
  if (!room) { res.status(404).json({ error: "Room not found" }); return; }
  const actor = actorFromRequest(req);
  logActivity({ ...actor, tenantId: tenantId ?? 1, action: "room.updated", entityType: "room", entityId: room.id, entityLabel: room.name, propertyId: room.propertyId ?? undefined });
  res.json(fmt(room));
});

router.delete("/rooms/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const tenantId = tid(req);
  const conds = [eq(roomsTable.id, id)];
  if (tenantId !== null) conds.push(eq(roomsTable.tenantId, tenantId));
  const [existing] = await db.select({ name: roomsTable.name, propertyId: roomsTable.propertyId }).from(roomsTable).where(and(...conds));
  await db.delete(roomsTable).where(and(...conds));
  const actor = actorFromRequest(req);
  logActivity({ ...actor, tenantId: tenantId ?? 1, action: "room.deleted", entityType: "room", entityId: id, entityLabel: existing?.name, propertyId: existing?.propertyId ?? undefined });
  res.status(204).end();
});

export default router;
