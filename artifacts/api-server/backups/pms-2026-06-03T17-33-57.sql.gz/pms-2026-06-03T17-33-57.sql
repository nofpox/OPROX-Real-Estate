--
-- PostgreSQL database dump
--

\restrict Bqjaqm6yVdrdge64T04vtOBnSMc8Kd7Z3S3VI6pjcKoEUfSnvlqfTIUOoePfIk9

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activity_logs (
    id integer NOT NULL,
    username text,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id integer,
    details text,
    ip_address text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    actor_name text,
    actor_role text,
    entity_label text,
    property_id integer,
    property_name text,
    actor_id integer,
    assigned_by_name text,
    completed_by_name text,
    proof_photo_url text,
    tenant_id integer DEFAULT 1 NOT NULL,
    action_type text,
    device_source text
);


ALTER TABLE public.activity_logs OWNER TO postgres;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activity_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activity_logs_id_seq OWNER TO postgres;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activity_logs_id_seq OWNED BY public.activity_logs.id;


--
-- Name: archiving_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.archiving_logs (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    run_at timestamp without time zone DEFAULT now() NOT NULL,
    triggered_by text DEFAULT 'system'::text NOT NULL,
    status text DEFAULT 'completed'::text NOT NULL,
    datasets text[],
    records_archived integer DEFAULT 0 NOT NULL,
    archive_keys text[],
    notes text,
    snoozed_until timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.archiving_logs OWNER TO postgres;

--
-- Name: archiving_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.archiving_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.archiving_logs_id_seq OWNER TO postgres;

--
-- Name: archiving_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.archiving_logs_id_seq OWNED BY public.archiving_logs.id;


--
-- Name: bookings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bookings (
    id integer NOT NULL,
    guest_name text NOT NULL,
    guest_email text NOT NULL,
    guest_phone text,
    room_id integer NOT NULL,
    check_in date NOT NULL,
    check_out date NOT NULL,
    status text DEFAULT 'confirmed'::text NOT NULL,
    total_amount numeric(10,2) NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    guest_id integer
);


ALTER TABLE public.bookings OWNER TO postgres;

--
-- Name: bookings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bookings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bookings_id_seq OWNER TO postgres;

--
-- Name: bookings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bookings_id_seq OWNED BY public.bookings.id;


--
-- Name: company_reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company_reports (
    id integer NOT NULL,
    tenant_id integer NOT NULL,
    title text NOT NULL,
    report_type text DEFAULT 'annual'::text NOT NULL,
    fiscal_year integer NOT NULL,
    fiscal_period text NOT NULL,
    file_url text,
    file_size_kb integer,
    published_at text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.company_reports OWNER TO postgres;

--
-- Name: company_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.company_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.company_reports_id_seq OWNER TO postgres;

--
-- Name: company_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.company_reports_id_seq OWNED BY public.company_reports.id;


--
-- Name: conversations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conversations (
    id integer NOT NULL,
    title text NOT NULL,
    agent_type text DEFAULT 'app'::text NOT NULL,
    user_id integer,
    tenant_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.conversations OWNER TO postgres;

--
-- Name: conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.conversations_id_seq OWNER TO postgres;

--
-- Name: conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.conversations_id_seq OWNED BY public.conversations.id;


--
-- Name: custom_fields; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_fields (
    id integer NOT NULL,
    entity_type text NOT NULL,
    field_key text NOT NULL,
    field_label text NOT NULL,
    field_type text DEFAULT 'text'::text NOT NULL,
    options text,
    required boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.custom_fields OWNER TO postgres;

--
-- Name: custom_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.custom_fields_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.custom_fields_id_seq OWNER TO postgres;

--
-- Name: custom_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.custom_fields_id_seq OWNED BY public.custom_fields.id;


--
-- Name: custom_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_roles (
    id integer NOT NULL,
    tenant_id integer,
    name text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    color text DEFAULT '#6366f1'::text NOT NULL,
    permissions text DEFAULT '[]'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.custom_roles OWNER TO postgres;

--
-- Name: custom_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.custom_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.custom_roles_id_seq OWNER TO postgres;

--
-- Name: custom_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.custom_roles_id_seq OWNED BY public.custom_roles.id;


--
-- Name: dividend_distributions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dividend_distributions (
    id integer NOT NULL,
    tenant_id integer NOT NULL,
    partner_id integer NOT NULL,
    amount numeric(14,2) NOT NULL,
    currency text DEFAULT 'AED'::text NOT NULL,
    distribution_date text NOT NULL,
    status text DEFAULT 'paid'::text NOT NULL,
    fiscal_period text NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.dividend_distributions OWNER TO postgres;

--
-- Name: dividend_distributions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dividend_distributions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dividend_distributions_id_seq OWNER TO postgres;

--
-- Name: dividend_distributions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dividend_distributions_id_seq OWNED BY public.dividend_distributions.id;


--
-- Name: equity_stakes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.equity_stakes (
    id integer NOT NULL,
    tenant_id integer NOT NULL,
    user_id integer NOT NULL,
    total_company_shares integer NOT NULL,
    partner_share_count integer NOT NULL,
    valuation_per_share numeric(14,4) NOT NULL,
    currency text DEFAULT 'AED'::text NOT NULL,
    effective_date text NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.equity_stakes OWNER TO postgres;

--
-- Name: equity_stakes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.equity_stakes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.equity_stakes_id_seq OWNER TO postgres;

--
-- Name: equity_stakes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.equity_stakes_id_seq OWNED BY public.equity_stakes.id;


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.expenses (
    id integer NOT NULL,
    property_id integer NOT NULL,
    unit_id integer,
    title text NOT NULL,
    category text NOT NULL,
    amount numeric(10,2) NOT NULL,
    expense_date date NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.expenses OWNER TO postgres;

--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.expenses_id_seq OWNER TO postgres;

--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.expenses_id_seq OWNED BY public.expenses.id;


--
-- Name: field_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.field_users (
    id integer NOT NULL,
    name text NOT NULL,
    role text NOT NULL,
    email text,
    phone text,
    property_id integer,
    status text DEFAULT 'active'::text NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.field_users OWNER TO postgres;

--
-- Name: field_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.field_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.field_users_id_seq OWNER TO postgres;

--
-- Name: field_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.field_users_id_seq OWNED BY public.field_users.id;


--
-- Name: guest_feedback; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.guest_feedback (
    id integer NOT NULL,
    room_id integer NOT NULL,
    rating text NOT NULL,
    comment text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.guest_feedback OWNER TO postgres;

--
-- Name: guest_feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.guest_feedback_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.guest_feedback_id_seq OWNER TO postgres;

--
-- Name: guest_feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.guest_feedback_id_seq OWNED BY public.guest_feedback.id;


--
-- Name: guest_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.guest_requests (
    id integer NOT NULL,
    room_id integer,
    type text NOT NULL,
    description text NOT NULL,
    facility_name text,
    scheduled_at text,
    visitor_name text,
    visitor_phone text,
    status text DEFAULT 'new'::text NOT NULL,
    ref_code text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.guest_requests OWNER TO postgres;

--
-- Name: guest_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.guest_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.guest_requests_id_seq OWNER TO postgres;

--
-- Name: guest_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.guest_requests_id_seq OWNED BY public.guest_requests.id;


--
-- Name: guests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.guests (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.guests OWNER TO postgres;

--
-- Name: guests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.guests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.guests_id_seq OWNER TO postgres;

--
-- Name: guests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.guests_id_seq OWNED BY public.guests.id;


--
-- Name: listing_inquiries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.listing_inquiries (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    listing_id integer,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    message text,
    source text DEFAULT 'web'::text NOT NULL,
    status text DEFAULT 'new'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.listing_inquiries OWNER TO postgres;

--
-- Name: listing_inquiries_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.listing_inquiries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.listing_inquiries_id_seq OWNER TO postgres;

--
-- Name: listing_inquiries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.listing_inquiries_id_seq OWNED BY public.listing_inquiries.id;


--
-- Name: listings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.listings (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    property_id integer,
    title text NOT NULL,
    description text,
    listing_type text DEFAULT 'sale'::text NOT NULL,
    property_type text DEFAULT 'apartment'::text NOT NULL,
    price numeric(12,2),
    currency text DEFAULT 'SAR'::text NOT NULL,
    area_sqm numeric(10,2),
    bedrooms integer,
    bathrooms integer,
    floor integer,
    amenities text DEFAULT '[]'::text,
    media text DEFAULT '[]'::text,
    address text,
    city text,
    district text,
    lat numeric(10,7),
    lng numeric(10,7),
    status text DEFAULT 'active'::text NOT NULL,
    featured boolean DEFAULT false NOT NULL,
    view_count integer DEFAULT 0 NOT NULL,
    contact_email text,
    contact_phone text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.listings OWNER TO postgres;

--
-- Name: listings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.listings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.listings_id_seq OWNER TO postgres;

--
-- Name: listings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.listings_id_seq OWNED BY public.listings.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id integer NOT NULL,
    conversation_id integer NOT NULL,
    role text NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.messages_id_seq OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    related_id integer,
    related_type text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    user_id integer,
    notif_key text,
    message_params text
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: portal_properties; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.portal_properties (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    name text NOT NULL,
    type text DEFAULT 'apartment'::text NOT NULL,
    address text NOT NULL,
    city text NOT NULL,
    country text DEFAULT 'SA'::text NOT NULL,
    description text,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.portal_properties OWNER TO postgres;

--
-- Name: portal_properties_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.portal_properties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.portal_properties_id_seq OWNER TO postgres;

--
-- Name: portal_properties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.portal_properties_id_seq OWNED BY public.portal_properties.id;


--
-- Name: portal_units; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.portal_units (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    portal_property_id integer NOT NULL,
    unit_number text NOT NULL,
    floor integer,
    type text DEFAULT 'apartment'::text NOT NULL,
    area numeric(10,2),
    bedroom_count integer DEFAULT 0,
    bathroom_count integer DEFAULT 1,
    status text DEFAULT 'available'::text NOT NULL,
    monthly_rent numeric(12,2),
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.portal_units OWNER TO postgres;

--
-- Name: portal_units_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.portal_units_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.portal_units_id_seq OWNER TO postgres;

--
-- Name: portal_units_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.portal_units_id_seq OWNED BY public.portal_units.id;


--
-- Name: properties; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.properties (
    id integer NOT NULL,
    name text NOT NULL,
    address text NOT NULL,
    city text NOT NULL,
    country text DEFAULT 'USA'::text NOT NULL,
    description text,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    type text DEFAULT 'hotel'::text NOT NULL
);


ALTER TABLE public.properties OWNER TO postgres;

--
-- Name: properties_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.properties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.properties_id_seq OWNER TO postgres;

--
-- Name: properties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.properties_id_seq OWNED BY public.properties.id;


--
-- Name: property_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.property_categories (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    slug text NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    icon text DEFAULT 'building-2'::text NOT NULL,
    color text DEFAULT 'blue'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.property_categories OWNER TO postgres;

--
-- Name: property_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.property_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.property_categories_id_seq OWNER TO postgres;

--
-- Name: property_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.property_categories_id_seq OWNED BY public.property_categories.id;


--
-- Name: rooms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rooms (
    id integer NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    price_per_night numeric(10,2) NOT NULL,
    status text DEFAULT 'available'::text NOT NULL,
    description text,
    capacity integer DEFAULT 2,
    amenities text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    property_id integer,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.rooms OWNER TO postgres;

--
-- Name: rooms_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rooms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rooms_id_seq OWNER TO postgres;

--
-- Name: rooms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rooms_id_seq OWNED BY public.rooms.id;


--
-- Name: service_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_categories (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    name text NOT NULL,
    icon text DEFAULT 'wrench'::text NOT NULL,
    color text DEFAULT 'amber'::text NOT NULL,
    property_types text DEFAULT 'all'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    priority text DEFAULT 'medium'::text NOT NULL,
    requires_time_slot boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.service_categories OWNER TO postgres;

--
-- Name: service_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.service_categories_id_seq OWNER TO postgres;

--
-- Name: service_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_categories_id_seq OWNED BY public.service_categories.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.settings (
    id integer NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.settings OWNER TO postgres;

--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.settings_id_seq OWNER TO postgres;

--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: shifts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shifts (
    id integer NOT NULL,
    staff_id integer NOT NULL,
    property_id integer NOT NULL,
    date date NOT NULL,
    shift_type text DEFAULT 'morning'::text NOT NULL,
    start_time text NOT NULL,
    end_time text NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.shifts OWNER TO postgres;

--
-- Name: shifts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shifts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shifts_id_seq OWNER TO postgres;

--
-- Name: shifts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shifts_id_seq OWNED BY public.shifts.id;


--
-- Name: staff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.staff (
    id integer NOT NULL,
    name text NOT NULL,
    role text NOT NULL,
    email text NOT NULL,
    phone text,
    property_id integer,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    system_role text DEFAULT 'supervisor'::text NOT NULL
);


ALTER TABLE public.staff OWNER TO postgres;

--
-- Name: staff_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.staff_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.staff_id_seq OWNER TO postgres;

--
-- Name: staff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.staff_id_seq OWNED BY public.staff.id;


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.support_tickets (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    category text DEFAULT 'issue'::text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    submitted_by_user_id integer,
    submitted_by_name text,
    submitted_by_role text,
    admin_notes text,
    resolved_by_user_id integer,
    resolved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.support_tickets OWNER TO postgres;

--
-- Name: support_tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.support_tickets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.support_tickets_id_seq OWNER TO postgres;

--
-- Name: support_tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.support_tickets_id_seq OWNED BY public.support_tickets.id;


--
-- Name: task_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_comments (
    id integer NOT NULL,
    task_id integer NOT NULL,
    author_name text NOT NULL,
    body text NOT NULL,
    image_url text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.task_comments OWNER TO postgres;

--
-- Name: task_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.task_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_comments_id_seq OWNER TO postgres;

--
-- Name: task_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.task_comments_id_seq OWNED BY public.task_comments.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    category text DEFAULT 'general'::text NOT NULL,
    property_id integer,
    unit_id integer,
    assigned_to_id integer,
    priority text DEFAULT 'medium'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    due_date date,
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    assigned_by_user_id integer,
    completed_by_user_id integer,
    proof_photo_url text,
    tenant_id integer DEFAULT 1 NOT NULL,
    supervisor_id integer,
    before_photo_url text,
    after_photo_url text,
    started_at timestamp with time zone,
    verified_at timestamp with time zone,
    verified_by_user_id integer,
    report_status text DEFAULT 'none'::text NOT NULL,
    submitted_at timestamp without time zone,
    submitted_by_user_id integer,
    rejected_at timestamp without time zone,
    rejected_by_user_id integer,
    rejection_notes text,
    escalated_at timestamp without time zone,
    escalated_by_user_id integer,
    approved_at timestamp without time zone,
    approved_by_user_id integer,
    completion_lat real,
    completion_lng real,
    completion_address text
);


ALTER TABLE public.tasks OWNER TO postgres;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tasks_id_seq OWNER TO postgres;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenants (
    id integer NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    plan text DEFAULT 'starter'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    contact_name text,
    contact_email text,
    contact_phone text,
    logo_text text,
    logo_sub text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.tenants OWNER TO postgres;

--
-- Name: tenants_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tenants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tenants_id_seq OWNER TO postgres;

--
-- Name: tenants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tenants_id_seq OWNED BY public.tenants.id;


--
-- Name: unit_financials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.unit_financials (
    id integer NOT NULL,
    room_id integer NOT NULL,
    status text DEFAULT 'available'::text NOT NULL,
    due_date text,
    amount_due numeric(10,2),
    check_in text,
    check_out text,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.unit_financials OWNER TO postgres;

--
-- Name: unit_financials_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.unit_financials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.unit_financials_id_seq OWNER TO postgres;

--
-- Name: unit_financials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.unit_financials_id_seq OWNED BY public.unit_financials.id;


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_sessions (
    session_id text NOT NULL,
    user_id integer NOT NULL,
    tenant_id integer,
    user_data jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    expires_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_sessions OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    display_name text NOT NULL,
    email text,
    password_hash text NOT NULL,
    role text DEFAULT 'staff'::text NOT NULL,
    permissions text DEFAULT '[]'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    must_change_password boolean DEFAULT true NOT NULL,
    tenant_id integer,
    phone_number text,
    custom_role_id integer
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: work_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.work_orders (
    id integer NOT NULL,
    property_id integer NOT NULL,
    unit_id integer,
    title text NOT NULL,
    description text,
    priority text DEFAULT 'medium'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    assigned_to text,
    due_date date,
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    cost numeric(10,2),
    tenant_id integer DEFAULT 1 NOT NULL,
    assigned_to_id integer
);


ALTER TABLE public.work_orders OWNER TO postgres;

--
-- Name: work_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.work_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.work_orders_id_seq OWNER TO postgres;

--
-- Name: work_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.work_orders_id_seq OWNED BY public.work_orders.id;


--
-- Name: activity_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_logs ALTER COLUMN id SET DEFAULT nextval('public.activity_logs_id_seq'::regclass);


--
-- Name: archiving_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.archiving_logs ALTER COLUMN id SET DEFAULT nextval('public.archiving_logs_id_seq'::regclass);


--
-- Name: bookings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings ALTER COLUMN id SET DEFAULT nextval('public.bookings_id_seq'::regclass);


--
-- Name: company_reports id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_reports ALTER COLUMN id SET DEFAULT nextval('public.company_reports_id_seq'::regclass);


--
-- Name: conversations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations ALTER COLUMN id SET DEFAULT nextval('public.conversations_id_seq'::regclass);


--
-- Name: custom_fields id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_fields ALTER COLUMN id SET DEFAULT nextval('public.custom_fields_id_seq'::regclass);


--
-- Name: custom_roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_roles ALTER COLUMN id SET DEFAULT nextval('public.custom_roles_id_seq'::regclass);


--
-- Name: dividend_distributions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dividend_distributions ALTER COLUMN id SET DEFAULT nextval('public.dividend_distributions_id_seq'::regclass);


--
-- Name: equity_stakes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equity_stakes ALTER COLUMN id SET DEFAULT nextval('public.equity_stakes_id_seq'::regclass);


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expenses ALTER COLUMN id SET DEFAULT nextval('public.expenses_id_seq'::regclass);


--
-- Name: field_users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.field_users ALTER COLUMN id SET DEFAULT nextval('public.field_users_id_seq'::regclass);


--
-- Name: guest_feedback id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guest_feedback ALTER COLUMN id SET DEFAULT nextval('public.guest_feedback_id_seq'::regclass);


--
-- Name: guest_requests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guest_requests ALTER COLUMN id SET DEFAULT nextval('public.guest_requests_id_seq'::regclass);


--
-- Name: guests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guests ALTER COLUMN id SET DEFAULT nextval('public.guests_id_seq'::regclass);


--
-- Name: listing_inquiries id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listing_inquiries ALTER COLUMN id SET DEFAULT nextval('public.listing_inquiries_id_seq'::regclass);


--
-- Name: listings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listings ALTER COLUMN id SET DEFAULT nextval('public.listings_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: portal_properties id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.portal_properties ALTER COLUMN id SET DEFAULT nextval('public.portal_properties_id_seq'::regclass);


--
-- Name: portal_units id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.portal_units ALTER COLUMN id SET DEFAULT nextval('public.portal_units_id_seq'::regclass);


--
-- Name: properties id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.properties ALTER COLUMN id SET DEFAULT nextval('public.properties_id_seq'::regclass);


--
-- Name: property_categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.property_categories ALTER COLUMN id SET DEFAULT nextval('public.property_categories_id_seq'::regclass);


--
-- Name: rooms id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms ALTER COLUMN id SET DEFAULT nextval('public.rooms_id_seq'::regclass);


--
-- Name: service_categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_categories ALTER COLUMN id SET DEFAULT nextval('public.service_categories_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: shifts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shifts ALTER COLUMN id SET DEFAULT nextval('public.shifts_id_seq'::regclass);


--
-- Name: staff id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff ALTER COLUMN id SET DEFAULT nextval('public.staff_id_seq'::regclass);


--
-- Name: support_tickets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets ALTER COLUMN id SET DEFAULT nextval('public.support_tickets_id_seq'::regclass);


--
-- Name: task_comments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_comments ALTER COLUMN id SET DEFAULT nextval('public.task_comments_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: tenants id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants ALTER COLUMN id SET DEFAULT nextval('public.tenants_id_seq'::regclass);


--
-- Name: unit_financials id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.unit_financials ALTER COLUMN id SET DEFAULT nextval('public.unit_financials_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: work_orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.work_orders ALTER COLUMN id SET DEFAULT nextval('public.work_orders_id_seq'::regclass);


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activity_logs (id, username, action, entity_type, entity_id, details, ip_address, created_at, actor_name, actor_role, entity_label, property_id, property_name, actor_id, assigned_by_name, completed_by_name, proof_photo_url, tenant_id, action_type, device_source) FROM stdin;
1	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 08:21:44.619191	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
2	\N	GET /settings	api_request	\N	{"statusCode":401,"endpointUrl":"/api/settings","actionType":"SETTINGS_CHANGE","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 08:21:44.656372	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
3	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 08:53:02.074866	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
4	\N	GET /settings	api_request	\N	{"statusCode":401,"endpointUrl":"/api/settings","actionType":"SETTINGS_CHANGE","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 08:53:02.098864	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
5	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 08:53:06.315152	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
6	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 09:44:57.750065	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
7	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 09:49:16.660796	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
8	\N	GET /settings	api_request	\N	{"statusCode":401,"endpointUrl":"/api/settings","actionType":"SETTINGS_CHANGE","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 09:49:16.68886	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
9	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 09:49:19.874159	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
10	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 11:37:39.784442	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
11	\N	GET /settings	api_request	\N	{"statusCode":401,"endpointUrl":"/api/settings","actionType":"SETTINGS_CHANGE","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 11:37:39.816643	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
12	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 11:46:45.454772	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
13	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 11:46:50.563679	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
14	\N	GET /settings	api_request	\N	{"statusCode":401,"endpointUrl":"/api/settings","actionType":"SETTINGS_CHANGE","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 11:46:50.607392	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
15	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 11:50:55.390689	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
16	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 12:22:01.444665	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
17	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 12:43:51.705716	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
18	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 12:44:28.260642	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
19	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 12:44:52.721432	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
20	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 12:45:04.643864	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
21	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 13:14:51.842859	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
22	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 13:29:32.664149	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
23	\N	GET /settings	api_request	\N	{"statusCode":401,"endpointUrl":"/api/settings","actionType":"SETTINGS_CHANGE","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 13:29:32.695592	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
24	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 13:59:15.6072	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
25	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 14:01:53.725789	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
26	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 14:17:06.528125	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
27	\N	GET /settings	api_request	\N	{"statusCode":401,"endpointUrl":"/api/settings","actionType":"SETTINGS_CHANGE","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 14:17:06.561171	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
28	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 14:30:19.962926	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
29	\N	GET /settings	api_request	\N	{"statusCode":401,"endpointUrl":"/api/settings","actionType":"SETTINGS_CHANGE","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 14:30:19.984676	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
30	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 14:49:59.079662	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
31	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 14:53:18.409993	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
32	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 16:19:12.638444	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
33	\N	GET /settings	api_request	\N	{"statusCode":401,"endpointUrl":"/api/settings","actionType":"SETTINGS_CHANGE","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 16:19:12.662557	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
\.


--
-- Data for Name: archiving_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.archiving_logs (id, tenant_id, run_at, triggered_by, status, datasets, records_archived, archive_keys, notes, snoozed_until, created_at) FROM stdin;
\.


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bookings (id, guest_name, guest_email, guest_phone, room_id, check_in, check_out, status, total_amount, notes, created_at, tenant_id, guest_id) FROM stdin;
\.


--
-- Data for Name: company_reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company_reports (id, tenant_id, title, report_type, fiscal_year, fiscal_period, file_url, file_size_kb, published_at, created_at) FROM stdin;
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.conversations (id, title, agent_type, user_id, tenant_id, created_at) FROM stdin;
\.


--
-- Data for Name: custom_fields; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_fields (id, entity_type, field_key, field_label, field_type, options, required, sort_order, active, created_at, updated_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: custom_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_roles (id, tenant_id, name, description, color, permissions, created_at) FROM stdin;
\.


--
-- Data for Name: dividend_distributions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dividend_distributions (id, tenant_id, partner_id, amount, currency, distribution_date, status, fiscal_period, notes, created_at) FROM stdin;
\.


--
-- Data for Name: equity_stakes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.equity_stakes (id, tenant_id, user_id, total_company_shares, partner_share_count, valuation_per_share, currency, effective_date, updated_at) FROM stdin;
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.expenses (id, property_id, unit_id, title, category, amount, expense_date, notes, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: field_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.field_users (id, name, role, email, phone, property_id, status, notes, created_at, updated_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: guest_feedback; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.guest_feedback (id, room_id, rating, comment, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: guest_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.guest_requests (id, room_id, type, description, facility_name, scheduled_at, visitor_name, visitor_phone, status, ref_code, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: guests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.guests (id, tenant_id, name, email, phone, created_at) FROM stdin;
\.


--
-- Data for Name: listing_inquiries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.listing_inquiries (id, tenant_id, listing_id, name, email, phone, message, source, status, created_at) FROM stdin;
\.


--
-- Data for Name: listings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.listings (id, tenant_id, property_id, title, description, listing_type, property_type, price, currency, area_sqm, bedrooms, bathrooms, floor, amenities, media, address, city, district, lat, lng, status, featured, view_count, contact_email, contact_phone, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, conversation_id, role, content, created_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, type, title, message, is_read, related_id, related_type, created_at, tenant_id, user_id, notif_key, message_params) FROM stdin;
\.


--
-- Data for Name: portal_properties; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.portal_properties (id, tenant_id, name, type, address, city, country, description, status, created_at) FROM stdin;
\.


--
-- Data for Name: portal_units; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.portal_units (id, tenant_id, portal_property_id, unit_number, floor, type, area, bedroom_count, bathroom_count, status, monthly_rent, notes, created_at) FROM stdin;
\.


--
-- Data for Name: properties; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.properties (id, name, address, city, country, description, status, created_at, tenant_id, type) FROM stdin;
\.


--
-- Data for Name: property_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.property_categories (id, tenant_id, slug, label_en, label_ar, icon, color, is_active, sort_order, created_at) FROM stdin;
1	1	hotel	Hotel	فندق	building-2	blue	t	1	2026-06-02 06:26:21.484862
2	1	apartment	Apartment	شقة	home	green	t	2	2026-06-02 06:26:21.484862
3	1	compound	Compound	مجمع	building	orange	t	3	2026-06-02 06:26:21.484862
4	1	villa	Villa	فيلا	landmark	purple	t	4	2026-06-02 06:26:21.484862
5	1	commercial	Commercial	تجاري	store	red	t	5	2026-06-02 06:26:21.484862
6	1	office	Office	مكتب	briefcase	slate	t	6	2026-06-02 06:26:21.484862
7	1	warehouse	Warehouse	مستودع	warehouse	amber	t	7	2026-06-02 06:26:21.484862
\.


--
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rooms (id, name, type, price_per_night, status, description, capacity, amenities, created_at, property_id, tenant_id) FROM stdin;
\.


--
-- Data for Name: service_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_categories (id, tenant_id, name, icon, color, property_types, is_active, sort_order, priority, requires_time_slot, created_at) FROM stdin;
1	1	Electrical	zap	yellow	all	t	1	high	f	2026-06-01 06:53:58.744634
2	1	Plumbing	droplets	blue	all	t	2	high	f	2026-06-01 06:53:58.744634
3	1	AC / Heating	wind	cyan	all	t	3	medium	f	2026-06-01 06:53:58.744634
4	1	Cleaning	brush	green	all	t	4	low	f	2026-06-01 06:53:58.744634
5	1	Maintenance	wrench	orange	all	t	5	high	f	2026-06-01 06:53:58.744634
6	1	Noise Complaint	volume-2	red	all	t	6	medium	f	2026-06-01 06:53:58.744634
7	1	Access / Keys	key	purple	compound,tower	t	7	medium	f	2026-06-01 06:53:58.744634
8	1	Internet / WiFi	wifi	indigo	all	t	8	medium	f	2026-06-01 06:53:58.744634
9	1	Parking	car	slate	compound,tower	t	9	low	f	2026-06-01 06:53:58.744634
10	1	Other	door-open	slate	all	t	10	low	f	2026-06-01 06:53:58.744634
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.settings (id, key, value, updated_at, tenant_id) FROM stdin;
1	propertyName	Grand PMS	2026-05-30 04:02:41.377305	1
2	logoText	Grand	2026-05-30 04:02:41.377305	1
3	logoSub	PMS	2026-05-30 04:02:41.377305	1
4	businessMode	hotel	2026-05-30 04:02:41.377305	1
7	contactEmail		2026-05-30 12:22:47.340205	1
8	contactPhone		2026-05-30 12:22:47.345069	1
9	contactAddress		2026-05-30 12:22:47.34774	1
10	taskTypes	[{"id":"reception","name":"Reception","color":"blue"},{"id":"housekeeping","name":"Housekeeping","color":"green"},{"id":"maintenance","name":"Maintenance","color":"orange"},{"id":"security","name":"Security","color":"red"},{"id":"general","name":"General","color":"gray"}]	2026-05-30 12:22:47.35073	1
11	taskRequirements	{"dueDate":false,"photoProof":false,"notes":false,"priority":false,"assignedTo":false}	2026-05-30 12:22:47.353123	1
12	logoUrl		2026-06-01 05:12:33.489202	1
13	navConfig	[{"id":"dashboard","order":0,"visible":true},{"id":"properties","order":1,"visible":true},{"id":"rooms","order":2,"visible":true},{"id":"unit-map","order":3,"visible":true},{"id":"maintenance","order":4,"visible":true},{"id":"facilities","order":5,"visible":true},{"id":"staff","order":6,"visible":true},{"id":"tasks","order":7,"visible":true},{"id":"guest-requests","order":8,"visible":true},{"id":"activity-log","order":9,"visible":true},{"id":"user-management","order":10,"visible":true},{"id":"admin-settings","order":11,"visible":true},{"id":"security-dashboard","order":12,"visible":true},{"id":"analytics","order":13,"visible":true},{"id":"support-tickets","order":14,"visible":true}]	2026-06-01 05:12:33.613752	1
15	primaryColor		2026-06-01 05:12:33.810559	1
16	secondaryColor		2026-06-01 05:12:33.814839	1
6	companyName	Rakez Smart Solutions	2026-06-01 20:58:17.579	1
5	enabledModules	["bookings","rooms","properties","guests","finance","maintenance","housekeeping","facilities","serviceRequests","staff","tasks","analytics","unitMap","guestRequests","activityLog","userManagement","supportTickets","serviceConfig","security"]	2026-06-01 23:06:05.115	1
14	permissionMatrix	{"admin_manager":[],"manager":[],"administrator":[],"supervisor":[],"maintenance":[],"cleaning":[],"security":[]}	2026-06-01 05:12:33.806255	1
19	portalRolePermissions	{"manager":["property:add","property:edit","marketing:listings"],"supervisor":["property:edit","marketing:listings"],"secretariat":["property:add","property:edit","support:inquiries"]}	2026-06-02 21:59:43.05852	1
\.


--
-- Data for Name: shifts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shifts (id, staff_id, property_id, date, shift_type, start_time, end_time, notes, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: staff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.staff (id, name, role, email, phone, property_id, status, created_at, tenant_id, system_role) FROM stdin;
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.support_tickets (id, tenant_id, category, title, description, status, submitted_by_user_id, submitted_by_name, submitted_by_role, admin_notes, resolved_by_user_id, resolved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_comments (id, task_id, author_name, body, image_url, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tasks (id, title, description, category, property_id, unit_id, assigned_to_id, priority, status, due_date, completed_at, created_at, assigned_by_user_id, completed_by_user_id, proof_photo_url, tenant_id, supervisor_id, before_photo_url, after_photo_url, started_at, verified_at, verified_by_user_id, report_status, submitted_at, submitted_by_user_id, rejected_at, rejected_by_user_id, rejection_notes, escalated_at, escalated_by_user_id, approved_at, approved_by_user_id, completion_lat, completion_lng, completion_address) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenants (id, name, slug, plan, status, contact_name, contact_email, contact_phone, logo_text, logo_sub, created_at, updated_at, is_active) FROM stdin;
1	ركز للحلول الذكية	rakez	enterprise	active	\N	\N	\N	ركز	للحلول الذكية	2026-05-30 12:51:22.596082	2026-05-30 15:00:32.047	t
\.


--
-- Data for Name: unit_financials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.unit_financials (id, room_id, status, due_date, amount_due, check_in, check_out, updated_at, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_sessions (session_id, user_id, tenant_id, user_data, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, display_name, email, password_hash, role, permissions, is_active, created_at, must_change_password, tenant_id, phone_number, custom_role_id) FROM stdin;
5	mike.torres	Mike Torres	mike.t@grandhotel.com	ae8c78347cea26a8b91d19ea18024522e0a68b417cea1e1bdff0f1a73b6dca0d	staff	[]	t	2026-05-30 23:48:57.832281	t	1	\N	\N
1	admin	Administrator	admin@grandpms.io	$2b$12$Gs9dvVTNocWjcN9ULwynKOAFoLc77tumYug4Rl2G7TKYVJWP7OvlS	owner	["all"]	t	2026-05-29 14:59:00.507436	f	1	+1-555-000-0001	\N
6	invite.test.flow	Invite Test	invite.test.flow@example.com	$2b$12$kTODYD6V3wvRE7ueVctktuJ7g0VTj00QJ5cd3TxLsPUhDWYM0HMHm	supervisor	[]	t	2026-06-01 17:11:55.043782	t	1	\N	\N
7	verify.onboard	Verification Employee	verify.onboard@rakez-test.io	$2b$12$1NkmnVwzPMRjGiYTA/PHV.jmb7s0meXQ53N05U8L7gzkIMS5Los7m	supervisor	[]	t	2026-06-01 17:16:29.186708	t	1	\N	\N
8	alice.unique	Alice Dupont	alice.unique@rakez-test.io	$2b$12$2AG20lZutNf4B/9ksffVjeXuhhXD4wfnPWUHg6G7buMzDfCKj3mea	supervisor	[]	t	2026-06-01 17:35:06.750555	t	1	\N	\N
9	bob.first	Bob First	bob.first@rakez-test.io	$2b$12$ZSaNO1j4oQaS.70xm0hkSubHHmTy0ap4rTOhK4quLj56r.Bveswua	supervisor	[]	t	2026-06-01 17:57:22.619402	t	1	+966501234567	\N
10	no.phone1	No Phone	no.phone1@rakez-test.io	$2b$12$cEWbkjGuK5HXjRT94QlQ/eBw3GwIfQUVtRx6FhFZfkIylnjP.p2lO	supervisor	[]	t	2026-06-01 17:57:23.295691	t	1	\N	\N
11	no.phone2	No Phone 2	no.phone2@rakez-test.io	$2b$12$UAUNyNZKf44ghhPiMCKYCOahXRKEJjaPOLq0jo1z0.sDaSLrLVbDa	supervisor	[]	t	2026-06-01 17:57:23.977121	t	1	\N	\N
2	testworker	Test Worker	worker@grandpms.io	$2b$12$Hk0hNKWZ.CW8asXOywPoBuUlP7W21t5AWeaIV7kCz5hFvVWyVs3qW	maintenance	[]	t	2026-05-30 11:20:24.977783	f	1	+1-555-000-0002	\N
12	investor1	Ahmed Al-Mansouri	investor@grandpms.com	$2b$12$sVAh4Hxf2U58rFyab5RwoeGw1tALZthHs55JxBZaG/S2IDzU0y2qC	partner	[]	t	2026-06-02 10:40:47.399104	f	1	+971501234567	\N
3	superadmin	Super Administrator	super@grandpms.io	$2b$12$0wi/lDZ.i.eZWuRfDa5y2.3JvpDR99WEREDZDR62quVzgUwITHKVS	super_admin	["all"]	t	2026-05-30 13:03:32.187128	t	\N	+1-555-000-0000	\N
4	sarah.collins	Sarah Collins	sarah.c@grandhotel.com	ae8c78347cea26a8b91d19ea18024522e0a68b417cea1e1bdff0f1a73b6dca0d	staff	["property:add","property:edit","marketing:campaigns","support:inquiries"]	t	2026-05-30 23:48:57.795242	t	1	\N	\N
13	testclient1	Test Client	test@example.com	$2b$12$yepOsfaUFeBPBbInY4UxY.Maz1qdzZWufRVhgs4kuM3OQurw8qgLu	client	[]	t	2026-06-02 22:40:30.484698	t	1	\N	\N
\.


--
-- Data for Name: work_orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.work_orders (id, property_id, unit_id, title, description, priority, status, assigned_to, due_date, completed_at, created_at, cost, tenant_id, assigned_to_id) FROM stdin;
\.


--
-- Name: activity_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activity_logs_id_seq', 33, true);


--
-- Name: archiving_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.archiving_logs_id_seq', 1, false);


--
-- Name: bookings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bookings_id_seq', 1, false);


--
-- Name: company_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.company_reports_id_seq', 1, false);


--
-- Name: conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.conversations_id_seq', 1, false);


--
-- Name: custom_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.custom_fields_id_seq', 1, false);


--
-- Name: custom_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.custom_roles_id_seq', 1, false);


--
-- Name: dividend_distributions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dividend_distributions_id_seq', 1, false);


--
-- Name: equity_stakes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.equity_stakes_id_seq', 1, false);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.expenses_id_seq', 1, false);


--
-- Name: field_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.field_users_id_seq', 1, false);


--
-- Name: guest_feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.guest_feedback_id_seq', 1, false);


--
-- Name: guest_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.guest_requests_id_seq', 1, false);


--
-- Name: guests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.guests_id_seq', 1, false);


--
-- Name: listing_inquiries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.listing_inquiries_id_seq', 1, false);


--
-- Name: listings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.listings_id_seq', 1, false);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.messages_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: portal_properties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.portal_properties_id_seq', 1, false);


--
-- Name: portal_units_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.portal_units_id_seq', 1, false);


--
-- Name: properties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.properties_id_seq', 1, false);


--
-- Name: property_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.property_categories_id_seq', 7, true);


--
-- Name: rooms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rooms_id_seq', 1, false);


--
-- Name: service_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_categories_id_seq', 10, true);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.settings_id_seq', 22, true);


--
-- Name: shifts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shifts_id_seq', 1, false);


--
-- Name: staff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.staff_id_seq', 1, false);


--
-- Name: support_tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.support_tickets_id_seq', 1, false);


--
-- Name: task_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.task_comments_id_seq', 1, false);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tasks_id_seq', 1, false);


--
-- Name: tenants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tenants_id_seq', 1, false);


--
-- Name: unit_financials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.unit_financials_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 13, true);


--
-- Name: work_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.work_orders_id_seq', 1, false);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: archiving_logs archiving_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.archiving_logs
    ADD CONSTRAINT archiving_logs_pkey PRIMARY KEY (id);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: company_reports company_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_reports
    ADD CONSTRAINT company_reports_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: custom_fields custom_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_fields
    ADD CONSTRAINT custom_fields_pkey PRIMARY KEY (id);


--
-- Name: custom_roles custom_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_roles
    ADD CONSTRAINT custom_roles_pkey PRIMARY KEY (id);


--
-- Name: dividend_distributions dividend_distributions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dividend_distributions
    ADD CONSTRAINT dividend_distributions_pkey PRIMARY KEY (id);


--
-- Name: equity_stakes equity_stakes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equity_stakes
    ADD CONSTRAINT equity_stakes_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: field_users field_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.field_users
    ADD CONSTRAINT field_users_pkey PRIMARY KEY (id);


--
-- Name: guest_feedback guest_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guest_feedback
    ADD CONSTRAINT guest_feedback_pkey PRIMARY KEY (id);


--
-- Name: guest_requests guest_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guest_requests
    ADD CONSTRAINT guest_requests_pkey PRIMARY KEY (id);


--
-- Name: guests guests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guests
    ADD CONSTRAINT guests_pkey PRIMARY KEY (id);


--
-- Name: guests guests_tenant_id_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guests
    ADD CONSTRAINT guests_tenant_id_email_key UNIQUE (tenant_id, email);


--
-- Name: listing_inquiries listing_inquiries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listing_inquiries
    ADD CONSTRAINT listing_inquiries_pkey PRIMARY KEY (id);


--
-- Name: listings listings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listings
    ADD CONSTRAINT listings_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: portal_properties portal_properties_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.portal_properties
    ADD CONSTRAINT portal_properties_pkey PRIMARY KEY (id);


--
-- Name: portal_units portal_units_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.portal_units
    ADD CONSTRAINT portal_units_pkey PRIMARY KEY (id);


--
-- Name: properties properties_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_pkey PRIMARY KEY (id);


--
-- Name: property_categories property_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.property_categories
    ADD CONSTRAINT property_categories_pkey PRIMARY KEY (id);


--
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (id);


--
-- Name: service_categories service_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_categories
    ADD CONSTRAINT service_categories_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: settings settings_tenant_key_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_tenant_key_uniq UNIQUE (tenant_id, key);


--
-- Name: shifts shifts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shifts
    ADD CONSTRAINT shifts_pkey PRIMARY KEY (id);


--
-- Name: staff staff_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: task_comments task_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_slug_key UNIQUE (slug);


--
-- Name: tenants tenants_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_slug_unique UNIQUE (slug);


--
-- Name: unit_financials unit_financials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.unit_financials
    ADD CONSTRAINT unit_financials_pkey PRIMARY KEY (id);


--
-- Name: unit_financials unit_financials_room_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.unit_financials
    ADD CONSTRAINT unit_financials_room_id_key UNIQUE (room_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (session_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: work_orders work_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.work_orders
    ADD CONSTRAINT work_orders_pkey PRIMARY KEY (id);


--
-- Name: bookings_tenant_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bookings_tenant_status_idx ON public.bookings USING btree (tenant_id, status);


--
-- Name: listing_inquiries_listing; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX listing_inquiries_listing ON public.listing_inquiries USING btree (listing_id);


--
-- Name: listings_featured; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX listings_featured ON public.listings USING btree (featured) WHERE (featured = true);


--
-- Name: listings_tenant_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX listings_tenant_status ON public.listings USING btree (tenant_id, status);


--
-- Name: notifications_tenant_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_tenant_idx ON public.notifications USING btree (tenant_id);


--
-- Name: notifications_tenant_unread_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_tenant_unread_idx ON public.notifications USING btree (tenant_id, is_read, created_at DESC);


--
-- Name: notifications_tenant_user_unread_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_tenant_user_unread_idx ON public.notifications USING btree (tenant_id, user_id, is_read, created_at DESC);


--
-- Name: staff_email_tenant_uniq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX staff_email_tenant_uniq ON public.staff USING btree (tenant_id, email);


--
-- Name: staff_phone_tenant_uniq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX staff_phone_tenant_uniq ON public.staff USING btree (tenant_id, phone) WHERE ((phone IS NOT NULL) AND (phone <> ''::text));


--
-- Name: staff_tenant_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX staff_tenant_idx ON public.staff USING btree (tenant_id);


--
-- Name: tasks_due_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tasks_due_date_idx ON public.tasks USING btree (due_date);


--
-- Name: tasks_tenant_assignee_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tasks_tenant_assignee_idx ON public.tasks USING btree (tenant_id, assigned_to_id);


--
-- Name: tasks_tenant_property_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tasks_tenant_property_idx ON public.tasks USING btree (tenant_id, property_id);


--
-- Name: tasks_tenant_report_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tasks_tenant_report_status_idx ON public.tasks USING btree (tenant_id, report_status);


--
-- Name: tasks_tenant_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tasks_tenant_status_idx ON public.tasks USING btree (tenant_id, status);


--
-- Name: tasks_tenant_supervisor_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tasks_tenant_supervisor_idx ON public.tasks USING btree (tenant_id, supervisor_id);


--
-- Name: user_sessions_expires_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_sessions_expires_idx ON public.user_sessions USING btree (expires_at);


--
-- Name: user_sessions_tenant_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_sessions_tenant_idx ON public.user_sessions USING btree (tenant_id);


--
-- Name: user_sessions_user_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_sessions_user_idx ON public.user_sessions USING btree (user_id);


--
-- Name: users_email_tenant_uniq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_email_tenant_uniq ON public.users USING btree (tenant_id, email) WHERE ((tenant_id IS NOT NULL) AND (email IS NOT NULL));


--
-- Name: users_phone_tenant_uniq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_phone_tenant_uniq ON public.users USING btree (tenant_id, phone_number) WHERE ((phone_number IS NOT NULL) AND (phone_number <> ''::text) AND (tenant_id IS NOT NULL));


--
-- Name: users_tenant_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_tenant_idx ON public.users USING btree (tenant_id);


--
-- Name: work_orders_tenant_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX work_orders_tenant_status_idx ON public.work_orders USING btree (tenant_id, status);


--
-- Name: messages messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: portal_units portal_units_portal_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.portal_units
    ADD CONSTRAINT portal_units_portal_property_id_fkey FOREIGN KEY (portal_property_id) REFERENCES public.portal_properties(id) ON DELETE CASCADE;


--
-- Name: task_comments task_comments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict Bqjaqm6yVdrdge64T04vtOBnSMc8Kd7Z3S3VI6pjcKoEUfSnvlqfTIUOoePfIk9

