--
-- PostgreSQL database dump
--

\restrict nhgXYfPSaiH5dSFDoCrQrNkXsgXm2iThbYzzhODFM6mZLNU7mONgwmd4P4v1icG

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activity_logs (
    id integer NOT NULL,
    username text,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id integer,
    details text,
    ip_address text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    actor_name text,
    actor_role text,
    entity_label text,
    property_id integer,
    property_name text,
    actor_id integer,
    assigned_by_name text,
    completed_by_name text,
    proof_photo_url text,
    tenant_id integer DEFAULT 1 NOT NULL,
    action_type text,
    device_source text
);


ALTER TABLE public.activity_logs OWNER TO postgres;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activity_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activity_logs_id_seq OWNER TO postgres;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activity_logs_id_seq OWNED BY public.activity_logs.id;


--
-- Name: ai_action_queue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_action_queue (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    action_type text NOT NULL,
    target_entity text NOT NULL,
    target_id integer,
    description text NOT NULL,
    payload jsonb,
    proposed_by text DEFAULT 'ai-engine'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    reviewed_by_id integer,
    reviewed_by_name text,
    review_note text,
    reviewed_at timestamp with time zone,
    executed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_action_queue OWNER TO postgres;

--
-- Name: ai_action_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_action_queue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_action_queue_id_seq OWNER TO postgres;

--
-- Name: ai_action_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_action_queue_id_seq OWNED BY public.ai_action_queue.id;


--
-- Name: ai_audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_audit_log (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    action_queue_id integer,
    event text NOT NULL,
    actor_type text DEFAULT 'ai'::text NOT NULL,
    actor_id integer,
    actor_name text,
    target_entity text,
    target_id integer,
    description text NOT NULL,
    before_state jsonb,
    after_state jsonb,
    metadata jsonb,
    ip_address text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_audit_log OWNER TO postgres;

--
-- Name: ai_audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_audit_log_id_seq OWNER TO postgres;

--
-- Name: ai_audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_audit_log_id_seq OWNED BY public.ai_audit_log.id;


--
-- Name: archiving_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.archiving_logs (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    run_at timestamp without time zone DEFAULT now() NOT NULL,
    triggered_by text DEFAULT 'system'::text NOT NULL,
    status text DEFAULT 'completed'::text NOT NULL,
    datasets text[],
    records_archived integer DEFAULT 0 NOT NULL,
    archive_keys text[],
    notes text,
    snoozed_until timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.archiving_logs OWNER TO postgres;

--
-- Name: archiving_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.archiving_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.archiving_logs_id_seq OWNER TO postgres;

--
-- Name: archiving_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.archiving_logs_id_seq OWNED BY public.archiving_logs.id;


--
-- Name: bookings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bookings (
    id integer NOT NULL,
    guest_name text NOT NULL,
    guest_email text NOT NULL,
    guest_phone text,
    room_id integer NOT NULL,
    check_in date NOT NULL,
    check_out date NOT NULL,
    status text DEFAULT 'confirmed'::text NOT NULL,
    total_amount numeric(10,2) NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    guest_id integer
);


ALTER TABLE public.bookings OWNER TO postgres;

--
-- Name: bookings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bookings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bookings_id_seq OWNER TO postgres;

--
-- Name: bookings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bookings_id_seq OWNED BY public.bookings.id;


--
-- Name: company_reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company_reports (
    id integer NOT NULL,
    tenant_id integer NOT NULL,
    title text NOT NULL,
    report_type text DEFAULT 'annual'::text NOT NULL,
    fiscal_year integer NOT NULL,
    fiscal_period text NOT NULL,
    file_url text,
    file_size_kb integer,
    published_at text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.company_reports OWNER TO postgres;

--
-- Name: company_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.company_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.company_reports_id_seq OWNER TO postgres;

--
-- Name: company_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.company_reports_id_seq OWNED BY public.company_reports.id;


--
-- Name: contracts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contracts (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    property_id integer NOT NULL,
    room_id integer NOT NULL,
    contract_number text NOT NULL,
    tenant_name text NOT NULL,
    tenant_phone text,
    tenant_email text,
    start_date date NOT NULL,
    end_date date NOT NULL,
    monthly_rent numeric(10,2) NOT NULL,
    deposit_amount numeric(10,2),
    status text DEFAULT 'active'::text NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.contracts OWNER TO postgres;

--
-- Name: contracts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contracts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.contracts_id_seq OWNER TO postgres;

--
-- Name: contracts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.contracts_id_seq OWNED BY public.contracts.id;


--
-- Name: conversations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conversations (
    id integer NOT NULL,
    title text NOT NULL,
    agent_type text DEFAULT 'app'::text NOT NULL,
    user_id integer,
    tenant_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.conversations OWNER TO postgres;

--
-- Name: conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.conversations_id_seq OWNER TO postgres;

--
-- Name: conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.conversations_id_seq OWNED BY public.conversations.id;


--
-- Name: custom_fields; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_fields (
    id integer NOT NULL,
    entity_type text NOT NULL,
    field_key text NOT NULL,
    field_label text NOT NULL,
    field_type text DEFAULT 'text'::text NOT NULL,
    options text,
    required boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.custom_fields OWNER TO postgres;

--
-- Name: custom_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.custom_fields_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.custom_fields_id_seq OWNER TO postgres;

--
-- Name: custom_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.custom_fields_id_seq OWNED BY public.custom_fields.id;


--
-- Name: custom_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_roles (
    id integer NOT NULL,
    tenant_id integer,
    name text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    color text DEFAULT '#6366f1'::text NOT NULL,
    permissions text DEFAULT '[]'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.custom_roles OWNER TO postgres;

--
-- Name: custom_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.custom_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.custom_roles_id_seq OWNER TO postgres;

--
-- Name: custom_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.custom_roles_id_seq OWNED BY public.custom_roles.id;


--
-- Name: dividend_distributions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dividend_distributions (
    id integer NOT NULL,
    tenant_id integer NOT NULL,
    partner_id integer NOT NULL,
    amount numeric(14,2) NOT NULL,
    currency text DEFAULT 'AED'::text NOT NULL,
    distribution_date text NOT NULL,
    status text DEFAULT 'paid'::text NOT NULL,
    fiscal_period text NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.dividend_distributions OWNER TO postgres;

--
-- Name: dividend_distributions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dividend_distributions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dividend_distributions_id_seq OWNER TO postgres;

--
-- Name: dividend_distributions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dividend_distributions_id_seq OWNED BY public.dividend_distributions.id;


--
-- Name: equity_stakes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.equity_stakes (
    id integer NOT NULL,
    tenant_id integer NOT NULL,
    user_id integer NOT NULL,
    total_company_shares integer NOT NULL,
    partner_share_count integer NOT NULL,
    valuation_per_share numeric(14,4) NOT NULL,
    currency text DEFAULT 'AED'::text NOT NULL,
    effective_date text NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.equity_stakes OWNER TO postgres;

--
-- Name: equity_stakes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.equity_stakes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.equity_stakes_id_seq OWNER TO postgres;

--
-- Name: equity_stakes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.equity_stakes_id_seq OWNED BY public.equity_stakes.id;


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.expenses (
    id integer NOT NULL,
    property_id integer NOT NULL,
    unit_id integer,
    title text NOT NULL,
    category text NOT NULL,
    amount numeric(10,2) NOT NULL,
    expense_date date NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.expenses OWNER TO postgres;

--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.expenses_id_seq OWNER TO postgres;

--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.expenses_id_seq OWNED BY public.expenses.id;


--
-- Name: field_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.field_users (
    id integer NOT NULL,
    name text NOT NULL,
    role text NOT NULL,
    email text,
    phone text,
    property_id integer,
    status text DEFAULT 'active'::text NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.field_users OWNER TO postgres;

--
-- Name: field_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.field_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.field_users_id_seq OWNER TO postgres;

--
-- Name: field_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.field_users_id_seq OWNED BY public.field_users.id;


--
-- Name: guest_feedback; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.guest_feedback (
    id integer NOT NULL,
    room_id integer NOT NULL,
    rating text NOT NULL,
    comment text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.guest_feedback OWNER TO postgres;

--
-- Name: guest_feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.guest_feedback_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.guest_feedback_id_seq OWNER TO postgres;

--
-- Name: guest_feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.guest_feedback_id_seq OWNED BY public.guest_feedback.id;


--
-- Name: guest_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.guest_requests (
    id integer NOT NULL,
    room_id integer,
    type text NOT NULL,
    description text NOT NULL,
    facility_name text,
    scheduled_at text,
    visitor_name text,
    visitor_phone text,
    status text DEFAULT 'new'::text NOT NULL,
    ref_code text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.guest_requests OWNER TO postgres;

--
-- Name: guest_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.guest_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.guest_requests_id_seq OWNER TO postgres;

--
-- Name: guest_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.guest_requests_id_seq OWNED BY public.guest_requests.id;


--
-- Name: guests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.guests (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.guests OWNER TO postgres;

--
-- Name: guests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.guests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.guests_id_seq OWNER TO postgres;

--
-- Name: guests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.guests_id_seq OWNED BY public.guests.id;


--
-- Name: inventory_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory_items (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    name text NOT NULL,
    category text DEFAULT 'general'::text NOT NULL,
    quantity numeric(10,2) DEFAULT 0 NOT NULL,
    min_quantity numeric(10,2) DEFAULT 5 NOT NULL,
    unit text DEFAULT 'piece'::text NOT NULL,
    location text,
    description text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.inventory_items OWNER TO postgres;

--
-- Name: inventory_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_items_id_seq OWNER TO postgres;

--
-- Name: inventory_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_items_id_seq OWNED BY public.inventory_items.id;


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoices (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    contract_id integer,
    property_id integer NOT NULL,
    room_id integer NOT NULL,
    invoice_number text NOT NULL,
    tenant_name text NOT NULL,
    amount numeric(10,2) NOT NULL,
    due_date date NOT NULL,
    issued_date date NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    notes text,
    paid_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.invoices OWNER TO postgres;

--
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invoices_id_seq OWNER TO postgres;

--
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.invoices_id_seq OWNED BY public.invoices.id;


--
-- Name: listing_inquiries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.listing_inquiries (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    listing_id integer,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    message text,
    source text DEFAULT 'web'::text NOT NULL,
    status text DEFAULT 'new'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.listing_inquiries OWNER TO postgres;

--
-- Name: listing_inquiries_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.listing_inquiries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.listing_inquiries_id_seq OWNER TO postgres;

--
-- Name: listing_inquiries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.listing_inquiries_id_seq OWNED BY public.listing_inquiries.id;


--
-- Name: listings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.listings (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    property_id integer,
    title text NOT NULL,
    description text,
    listing_type text DEFAULT 'sale'::text NOT NULL,
    property_type text DEFAULT 'apartment'::text NOT NULL,
    price numeric(12,2),
    currency text DEFAULT 'SAR'::text NOT NULL,
    area_sqm numeric(10,2),
    bedrooms integer,
    bathrooms integer,
    floor integer,
    amenities text DEFAULT '[]'::text,
    media text DEFAULT '[]'::text,
    address text,
    city text,
    district text,
    lat numeric(10,7),
    lng numeric(10,7),
    status text DEFAULT 'active'::text NOT NULL,
    featured boolean DEFAULT false NOT NULL,
    view_count integer DEFAULT 0 NOT NULL,
    contact_email text,
    contact_phone text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.listings OWNER TO postgres;

--
-- Name: listings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.listings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.listings_id_seq OWNER TO postgres;

--
-- Name: listings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.listings_id_seq OWNED BY public.listings.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id integer NOT NULL,
    conversation_id integer NOT NULL,
    role text NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.messages_id_seq OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    related_id integer,
    related_type text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    user_id integer,
    notif_key text,
    message_params text
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: portal_properties; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.portal_properties (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    name text NOT NULL,
    type text DEFAULT 'apartment'::text NOT NULL,
    address text NOT NULL,
    city text NOT NULL,
    country text DEFAULT 'SA'::text NOT NULL,
    description text,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.portal_properties OWNER TO postgres;

--
-- Name: portal_properties_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.portal_properties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.portal_properties_id_seq OWNER TO postgres;

--
-- Name: portal_properties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.portal_properties_id_seq OWNED BY public.portal_properties.id;


--
-- Name: portal_units; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.portal_units (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    portal_property_id integer NOT NULL,
    unit_number text NOT NULL,
    floor integer,
    type text DEFAULT 'apartment'::text NOT NULL,
    area numeric(10,2),
    bedroom_count integer DEFAULT 0,
    bathroom_count integer DEFAULT 1,
    status text DEFAULT 'available'::text NOT NULL,
    monthly_rent numeric(12,2),
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.portal_units OWNER TO postgres;

--
-- Name: portal_units_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.portal_units_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.portal_units_id_seq OWNER TO postgres;

--
-- Name: portal_units_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.portal_units_id_seq OWNED BY public.portal_units.id;


--
-- Name: preview_links; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.preview_links (
    id integer NOT NULL,
    token uuid DEFAULT gen_random_uuid() NOT NULL,
    portal text NOT NULL,
    label text DEFAULT ''::text NOT NULL,
    created_by text DEFAULT 'admin'::text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.preview_links OWNER TO postgres;

--
-- Name: preview_links_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.preview_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.preview_links_id_seq OWNER TO postgres;

--
-- Name: preview_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.preview_links_id_seq OWNED BY public.preview_links.id;


--
-- Name: properties; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.properties (
    id integer NOT NULL,
    name text NOT NULL,
    address text NOT NULL,
    city text NOT NULL,
    country text DEFAULT 'USA'::text NOT NULL,
    description text,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    type text DEFAULT 'hotel'::text NOT NULL
);


ALTER TABLE public.properties OWNER TO postgres;

--
-- Name: properties_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.properties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.properties_id_seq OWNER TO postgres;

--
-- Name: properties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.properties_id_seq OWNED BY public.properties.id;


--
-- Name: property_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.property_categories (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    slug text NOT NULL,
    label_en text NOT NULL,
    label_ar text,
    icon text DEFAULT 'building-2'::text NOT NULL,
    color text DEFAULT 'blue'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.property_categories OWNER TO postgres;

--
-- Name: property_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.property_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.property_categories_id_seq OWNER TO postgres;

--
-- Name: property_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.property_categories_id_seq OWNED BY public.property_categories.id;


--
-- Name: rkz_listings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rkz_listings (
    id integer NOT NULL,
    user_id integer NOT NULL,
    type text NOT NULL,
    price numeric(14,2) NOT NULL,
    currency text DEFAULT 'SAR'::text NOT NULL,
    city text NOT NULL,
    district text,
    address text,
    lat numeric(10,7),
    lng numeric(10,7),
    area numeric(10,2),
    bedrooms integer,
    bathrooms integer,
    title text,
    description text,
    photos text DEFAULT '[]'::text NOT NULL,
    platforms text DEFAULT '[]'::text NOT NULL,
    status text DEFAULT 'publishing'::text NOT NULL,
    featured boolean DEFAULT false NOT NULL,
    view_count integer DEFAULT 0 NOT NULL,
    published_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.rkz_listings OWNER TO postgres;

--
-- Name: rkz_listings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rkz_listings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rkz_listings_id_seq OWNER TO postgres;

--
-- Name: rkz_listings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rkz_listings_id_seq OWNED BY public.rkz_listings.id;


--
-- Name: rkz_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rkz_users (
    id integer NOT NULL,
    phone text NOT NULL,
    name text,
    email text,
    authorized boolean DEFAULT false NOT NULL,
    auth_token text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.rkz_users OWNER TO postgres;

--
-- Name: rkz_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rkz_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rkz_users_id_seq OWNER TO postgres;

--
-- Name: rkz_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rkz_users_id_seq OWNED BY public.rkz_users.id;


--
-- Name: rooms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rooms (
    id integer NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    price_per_night numeric(10,2) NOT NULL,
    status text DEFAULT 'available'::text NOT NULL,
    description text,
    capacity integer DEFAULT 2,
    amenities text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    property_id integer,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.rooms OWNER TO postgres;

--
-- Name: rooms_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rooms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rooms_id_seq OWNER TO postgres;

--
-- Name: rooms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rooms_id_seq OWNED BY public.rooms.id;


--
-- Name: saved_searches; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.saved_searches (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    user_id integer NOT NULL,
    name text NOT NULL,
    criteria text DEFAULT '{}'::text NOT NULL,
    notify_email boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.saved_searches OWNER TO postgres;

--
-- Name: saved_searches_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.saved_searches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.saved_searches_id_seq OWNER TO postgres;

--
-- Name: saved_searches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.saved_searches_id_seq OWNED BY public.saved_searches.id;


--
-- Name: service_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_categories (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    name text NOT NULL,
    icon text DEFAULT 'wrench'::text NOT NULL,
    color text DEFAULT 'amber'::text NOT NULL,
    property_types text DEFAULT 'all'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    priority text DEFAULT 'medium'::text NOT NULL,
    requires_time_slot boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.service_categories OWNER TO postgres;

--
-- Name: service_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.service_categories_id_seq OWNER TO postgres;

--
-- Name: service_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_categories_id_seq OWNED BY public.service_categories.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.settings (
    id integer NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.settings OWNER TO postgres;

--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.settings_id_seq OWNER TO postgres;

--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: shifts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shifts (
    id integer NOT NULL,
    staff_id integer NOT NULL,
    property_id integer NOT NULL,
    date date NOT NULL,
    shift_type text DEFAULT 'morning'::text NOT NULL,
    start_time text NOT NULL,
    end_time text NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.shifts OWNER TO postgres;

--
-- Name: shifts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shifts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shifts_id_seq OWNER TO postgres;

--
-- Name: shifts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shifts_id_seq OWNED BY public.shifts.id;


--
-- Name: staff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.staff (
    id integer NOT NULL,
    name text NOT NULL,
    role text NOT NULL,
    email text NOT NULL,
    phone text,
    property_id integer,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    system_role text DEFAULT 'supervisor'::text NOT NULL
);


ALTER TABLE public.staff OWNER TO postgres;

--
-- Name: staff_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.staff_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.staff_id_seq OWNER TO postgres;

--
-- Name: staff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.staff_id_seq OWNED BY public.staff.id;


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.support_tickets (
    id integer NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    category text DEFAULT 'issue'::text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    submitted_by_user_id integer,
    submitted_by_name text,
    submitted_by_role text,
    admin_notes text,
    resolved_by_user_id integer,
    resolved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.support_tickets OWNER TO postgres;

--
-- Name: support_tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.support_tickets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.support_tickets_id_seq OWNER TO postgres;

--
-- Name: support_tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.support_tickets_id_seq OWNED BY public.support_tickets.id;


--
-- Name: task_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_comments (
    id integer NOT NULL,
    task_id integer NOT NULL,
    author_name text NOT NULL,
    body text NOT NULL,
    image_url text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.task_comments OWNER TO postgres;

--
-- Name: task_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.task_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_comments_id_seq OWNER TO postgres;

--
-- Name: task_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.task_comments_id_seq OWNED BY public.task_comments.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    category text DEFAULT 'general'::text NOT NULL,
    property_id integer,
    unit_id integer,
    assigned_to_id integer,
    priority text DEFAULT 'medium'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    due_date date,
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    assigned_by_user_id integer,
    completed_by_user_id integer,
    proof_photo_url text,
    tenant_id integer DEFAULT 1 NOT NULL,
    supervisor_id integer,
    before_photo_url text,
    after_photo_url text,
    started_at timestamp with time zone,
    verified_at timestamp with time zone,
    verified_by_user_id integer,
    report_status text DEFAULT 'none'::text NOT NULL,
    submitted_at timestamp without time zone,
    submitted_by_user_id integer,
    rejected_at timestamp without time zone,
    rejected_by_user_id integer,
    rejection_notes text,
    escalated_at timestamp without time zone,
    escalated_by_user_id integer,
    approved_at timestamp without time zone,
    approved_by_user_id integer,
    completion_lat real,
    completion_lng real,
    completion_address text
);


ALTER TABLE public.tasks OWNER TO postgres;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tasks_id_seq OWNER TO postgres;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenants (
    id integer NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    plan text DEFAULT 'starter'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    contact_name text,
    contact_email text,
    contact_phone text,
    logo_text text,
    logo_sub text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.tenants OWNER TO postgres;

--
-- Name: tenants_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tenants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tenants_id_seq OWNER TO postgres;

--
-- Name: tenants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tenants_id_seq OWNED BY public.tenants.id;


--
-- Name: unit_financials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.unit_financials (
    id integer NOT NULL,
    room_id integer NOT NULL,
    status text DEFAULT 'available'::text NOT NULL,
    due_date text,
    amount_due numeric(10,2),
    check_in text,
    check_out text,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.unit_financials OWNER TO postgres;

--
-- Name: unit_financials_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.unit_financials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.unit_financials_id_seq OWNER TO postgres;

--
-- Name: unit_financials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.unit_financials_id_seq OWNED BY public.unit_financials.id;


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_sessions (
    session_id text NOT NULL,
    user_id integer NOT NULL,
    tenant_id integer,
    user_data jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    expires_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_sessions OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    display_name text NOT NULL,
    email text,
    password_hash text NOT NULL,
    role text DEFAULT 'staff'::text NOT NULL,
    permissions text DEFAULT '[]'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    must_change_password boolean DEFAULT true NOT NULL,
    tenant_id integer,
    phone_number text,
    custom_role_id integer
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: webauthn_credentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.webauthn_credentials (
    id integer NOT NULL,
    user_id integer NOT NULL,
    credential_id text NOT NULL,
    public_key text NOT NULL,
    counter bigint DEFAULT 0 NOT NULL,
    transports text DEFAULT '[]'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.webauthn_credentials OWNER TO postgres;

--
-- Name: webauthn_credentials_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.webauthn_credentials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.webauthn_credentials_id_seq OWNER TO postgres;

--
-- Name: webauthn_credentials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.webauthn_credentials_id_seq OWNED BY public.webauthn_credentials.id;


--
-- Name: work_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.work_orders (
    id integer NOT NULL,
    property_id integer NOT NULL,
    unit_id integer,
    title text NOT NULL,
    description text,
    priority text DEFAULT 'medium'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    assigned_to text,
    due_date date,
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    cost numeric(10,2),
    tenant_id integer DEFAULT 1 NOT NULL,
    assigned_to_id integer
);


ALTER TABLE public.work_orders OWNER TO postgres;

--
-- Name: work_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.work_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.work_orders_id_seq OWNER TO postgres;

--
-- Name: work_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.work_orders_id_seq OWNED BY public.work_orders.id;


--
-- Name: activity_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_logs ALTER COLUMN id SET DEFAULT nextval('public.activity_logs_id_seq'::regclass);


--
-- Name: ai_action_queue id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_action_queue ALTER COLUMN id SET DEFAULT nextval('public.ai_action_queue_id_seq'::regclass);


--
-- Name: ai_audit_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_audit_log ALTER COLUMN id SET DEFAULT nextval('public.ai_audit_log_id_seq'::regclass);


--
-- Name: archiving_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.archiving_logs ALTER COLUMN id SET DEFAULT nextval('public.archiving_logs_id_seq'::regclass);


--
-- Name: bookings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings ALTER COLUMN id SET DEFAULT nextval('public.bookings_id_seq'::regclass);


--
-- Name: company_reports id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_reports ALTER COLUMN id SET DEFAULT nextval('public.company_reports_id_seq'::regclass);


--
-- Name: contracts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts ALTER COLUMN id SET DEFAULT nextval('public.contracts_id_seq'::regclass);


--
-- Name: conversations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations ALTER COLUMN id SET DEFAULT nextval('public.conversations_id_seq'::regclass);


--
-- Name: custom_fields id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_fields ALTER COLUMN id SET DEFAULT nextval('public.custom_fields_id_seq'::regclass);


--
-- Name: custom_roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_roles ALTER COLUMN id SET DEFAULT nextval('public.custom_roles_id_seq'::regclass);


--
-- Name: dividend_distributions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dividend_distributions ALTER COLUMN id SET DEFAULT nextval('public.dividend_distributions_id_seq'::regclass);


--
-- Name: equity_stakes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equity_stakes ALTER COLUMN id SET DEFAULT nextval('public.equity_stakes_id_seq'::regclass);


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expenses ALTER COLUMN id SET DEFAULT nextval('public.expenses_id_seq'::regclass);


--
-- Name: field_users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.field_users ALTER COLUMN id SET DEFAULT nextval('public.field_users_id_seq'::regclass);


--
-- Name: guest_feedback id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guest_feedback ALTER COLUMN id SET DEFAULT nextval('public.guest_feedback_id_seq'::regclass);


--
-- Name: guest_requests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guest_requests ALTER COLUMN id SET DEFAULT nextval('public.guest_requests_id_seq'::regclass);


--
-- Name: guests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guests ALTER COLUMN id SET DEFAULT nextval('public.guests_id_seq'::regclass);


--
-- Name: inventory_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_items ALTER COLUMN id SET DEFAULT nextval('public.inventory_items_id_seq'::regclass);


--
-- Name: invoices id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices ALTER COLUMN id SET DEFAULT nextval('public.invoices_id_seq'::regclass);


--
-- Name: listing_inquiries id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listing_inquiries ALTER COLUMN id SET DEFAULT nextval('public.listing_inquiries_id_seq'::regclass);


--
-- Name: listings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listings ALTER COLUMN id SET DEFAULT nextval('public.listings_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: portal_properties id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.portal_properties ALTER COLUMN id SET DEFAULT nextval('public.portal_properties_id_seq'::regclass);


--
-- Name: portal_units id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.portal_units ALTER COLUMN id SET DEFAULT nextval('public.portal_units_id_seq'::regclass);


--
-- Name: preview_links id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preview_links ALTER COLUMN id SET DEFAULT nextval('public.preview_links_id_seq'::regclass);


--
-- Name: properties id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.properties ALTER COLUMN id SET DEFAULT nextval('public.properties_id_seq'::regclass);


--
-- Name: property_categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.property_categories ALTER COLUMN id SET DEFAULT nextval('public.property_categories_id_seq'::regclass);


--
-- Name: rkz_listings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rkz_listings ALTER COLUMN id SET DEFAULT nextval('public.rkz_listings_id_seq'::regclass);


--
-- Name: rkz_users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rkz_users ALTER COLUMN id SET DEFAULT nextval('public.rkz_users_id_seq'::regclass);


--
-- Name: rooms id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms ALTER COLUMN id SET DEFAULT nextval('public.rooms_id_seq'::regclass);


--
-- Name: saved_searches id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saved_searches ALTER COLUMN id SET DEFAULT nextval('public.saved_searches_id_seq'::regclass);


--
-- Name: service_categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_categories ALTER COLUMN id SET DEFAULT nextval('public.service_categories_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: shifts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shifts ALTER COLUMN id SET DEFAULT nextval('public.shifts_id_seq'::regclass);


--
-- Name: staff id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff ALTER COLUMN id SET DEFAULT nextval('public.staff_id_seq'::regclass);


--
-- Name: support_tickets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets ALTER COLUMN id SET DEFAULT nextval('public.support_tickets_id_seq'::regclass);


--
-- Name: task_comments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_comments ALTER COLUMN id SET DEFAULT nextval('public.task_comments_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: tenants id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants ALTER COLUMN id SET DEFAULT nextval('public.tenants_id_seq'::regclass);


--
-- Name: unit_financials id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.unit_financials ALTER COLUMN id SET DEFAULT nextval('public.unit_financials_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: webauthn_credentials id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webauthn_credentials ALTER COLUMN id SET DEFAULT nextval('public.webauthn_credentials_id_seq'::regclass);


--
-- Name: work_orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.work_orders ALTER COLUMN id SET DEFAULT nextval('public.work_orders_id_seq'::regclass);


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activity_logs (id, username, action, entity_type, entity_id, details, ip_address, created_at, actor_name, actor_role, entity_label, property_id, property_name, actor_id, assigned_by_name, completed_by_name, proof_photo_url, tenant_id, action_type, device_source) FROM stdin;
1	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 08:21:44.619191	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
2	\N	GET /settings	api_request	\N	{"statusCode":401,"endpointUrl":"/api/settings","actionType":"SETTINGS_CHANGE","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 08:21:44.656372	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
3	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 08:53:02.074866	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
4	\N	GET /settings	api_request	\N	{"statusCode":401,"endpointUrl":"/api/settings","actionType":"SETTINGS_CHANGE","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 08:53:02.098864	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
5	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 08:53:06.315152	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
6	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 09:44:57.750065	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
7	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 09:49:16.660796	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
8	\N	GET /settings	api_request	\N	{"statusCode":401,"endpointUrl":"/api/settings","actionType":"SETTINGS_CHANGE","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 09:49:16.68886	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
9	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 09:49:19.874159	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
10	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 11:37:39.784442	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
11	\N	GET /settings	api_request	\N	{"statusCode":401,"endpointUrl":"/api/settings","actionType":"SETTINGS_CHANGE","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 11:37:39.816643	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
12	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 11:46:45.454772	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
13	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 11:46:50.563679	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
14	\N	GET /settings	api_request	\N	{"statusCode":401,"endpointUrl":"/api/settings","actionType":"SETTINGS_CHANGE","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 11:46:50.607392	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
15	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 11:50:55.390689	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
16	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 12:22:01.444665	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
17	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 12:43:51.705716	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
18	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 12:44:28.260642	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
19	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 12:44:52.721432	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
20	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 12:45:04.643864	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
21	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 13:14:51.842859	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
22	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 13:29:32.664149	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
124	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:28:46.886689	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
23	\N	GET /settings	api_request	\N	{"statusCode":401,"endpointUrl":"/api/settings","actionType":"SETTINGS_CHANGE","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 13:29:32.695592	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
24	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 13:59:15.6072	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
25	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 14:01:53.725789	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
26	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 14:17:06.528125	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
27	\N	GET /settings	api_request	\N	{"statusCode":401,"endpointUrl":"/api/settings","actionType":"SETTINGS_CHANGE","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 14:17:06.561171	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
28	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 14:30:19.962926	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
29	\N	GET /settings	api_request	\N	{"statusCode":401,"endpointUrl":"/api/settings","actionType":"SETTINGS_CHANGE","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 14:30:19.984676	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
30	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 14:49:59.079662	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
31	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 14:53:18.409993	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
32	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 16:19:12.638444	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
33	\N	GET /settings	api_request	\N	{"statusCode":401,"endpointUrl":"/api/settings","actionType":"SETTINGS_CHANGE","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 16:19:12.662557	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
34	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 17:56:19.654127	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
35	\N	GET /settings	api_request	\N	{"statusCode":401,"endpointUrl":"/api/settings","actionType":"SETTINGS_CHANGE","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 17:56:19.689279	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
36	\N	POST /rkz/suggest-price	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/suggest-price","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"type":"villa","city":"الرياض","district":"النرجس","area":400,"bedrooms":5}}	\N	2026-06-03 20:32:21.490725	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
37	\N	POST /rkz/suggest-price	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/suggest-price","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"type":"villa","city":"الرياض","district":"النرجس","area":400,"bedrooms":5}}	\N	2026-06-03 20:32:53.585012	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
38	\N	POST /rkz/generate-description	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/generate-description","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"type":"villa","city":"الرياض","district":"النرجس","area":400,"bedrooms":5,"price":2500000}}	\N	2026-06-03 20:32:57.541021	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
39	\N	POST /rkz/suggest-price	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/suggest-price","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"type":"villa","city":"الرياض","district":"النرجس","area":400,"bedrooms":5}}	\N	2026-06-03 20:34:19.372541	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
40	\N	POST /rkz/suggest-price	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/suggest-price","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"type":"villa","city":"الرياض","district":"النرجس","area":400,"bedrooms":5}}	\N	2026-06-03 20:35:34.047342	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
41	\N	POST /rkz/suggest-price	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/suggest-price","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"type":"villa","city":"الرياض","district":"النرجس","area":400,"bedrooms":5}}	\N	2026-06-03 20:37:04.367392	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
42	\N	POST /rkz/generate-description	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/generate-description","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"type":"villa","city":"الرياض","district":"النرجس","area":400,"bedrooms":5,"price":2500000}}	\N	2026-06-03 20:37:18.649362	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
43	\N	POST /rkz/generate-description	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/generate-description","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"type":"villa","city":"الرياض","district":"النرجس","area":400,"bedrooms":5,"price":2500000}}	\N	2026-06-03 20:38:02.35732	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
44	\N	POST /rkz/generate-description	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/generate-description","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"type":"villa","city":"الرياض","district":"النرجس","area":400,"bedrooms":5,"price":2500000}}	\N	2026-06-03 20:38:24.623541	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
45	\N	POST /rkz/suggest-price	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/suggest-price","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"type":"villa","city":"الرياض","district":"النرجس","area":400,"bedrooms":5}}	\N	2026-06-03 20:39:23.974306	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
46	\N	POST /rkz/generate-description	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/generate-description","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"type":"villa","city":"الرياض","district":"النرجس","area":400,"bedrooms":5,"price":2500000}}	\N	2026-06-03 20:39:32.875784	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
47	\N	POST /rkz/suggest-price	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/suggest-price","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"type":"apartment","city":"جدة","district":"الشاطئ","area":180,"bedrooms":3}}	\N	2026-06-03 20:40:04.601496	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
48	\N	POST /rkz/suggest-price	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/suggest-price","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"type":"villa","city":"الرياض","district":"النرجس","area":400,"bedrooms":5}}	\N	2026-06-03 20:42:09.970981	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
49	\N	POST /rkz/generate-description	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/generate-description","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"type":"villa","city":"الرياض","district":"النرجس","area":400,"bedrooms":5,"price":2500000}}	\N	2026-06-03 20:42:13.010204	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
50	\N	POST /rkz/admin/verify-pin	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/admin/verify-pin","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"pin":"1234"}}	\N	2026-06-03 21:43:46.537913	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
51	\N	POST /rkz/admin/verify-pin	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/admin/verify-pin","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"pin":"0000"}}	\N	2026-06-03 21:43:46.582332	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
52	\N	PATCH /rkz/admin/config	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/admin/config","actionType":"UPDATE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"pin":"1234","updates":{"branding":{"primaryColor":"#10B981","navyColor":"#064E3B"}}}}	\N	2026-06-03 21:43:55.438804	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
53	\N	PATCH /rkz/admin/config	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/admin/config","actionType":"UPDATE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"pin":"1234","updates":{"branding":{"primaryColor":"#D4A843","navyColor":"#0A1628","backgroundColor":"#F5F7FA"}}}}	\N	2026-06-03 21:44:04.010533	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
54	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 23:42:51.963136	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
55	\N	POST /rkz/auth/login	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/auth/login","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"phone":"+966599999999","name":"Test Broker"}}	\N	2026-06-03 23:43:05.096268	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
56	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 23:43:33.266437	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
57	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-03 23:43:53.275294	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
58	\N	POST /rkz/portal/auth/login	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/portal/auth/login","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"username":"admin","password":"[REDACTED]"}}	\N	2026-06-03 23:57:08.064795	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
59	\N	GET /rkz/portal/auth/me	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/portal/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":null}	\N	2026-06-03 23:57:16.600478	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
60	\N	POST /rkz/portal/auth/login	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/portal/auth/login","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"username":"admin","password":"[REDACTED]"}}	\N	2026-06-04 00:01:28.134484	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
61	\N	POST /rkz/portal/auth/login	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/portal/auth/login","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"username":"admin","password":"[REDACTED]"}}	\N	2026-06-04 00:01:44.850372	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
62	\N	POST /rkz/auth/login	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/auth/login","actionType":"AUTH_LOGIN","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":{"phone":"+966111111111"}}	\N	2026-06-04 00:36:23.849782	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
63	\N	POST /rkz/assistant/chat	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/assistant/chat","actionType":"WRITE","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":{"messages":[{"role":"assistant","content":"مرحباً! أنا مساعد ركز الذكي ✨\\n\\nمحفظتك تضم **0** عقارات، 0 منها منشورة مع **٠** مشاهدة و**0** مستفسر.\\n\\nاسألني عن أداء عقاراتك، التسعير، استراتيجية النشر، أو أي شيء عن السوق السعودي."},{"role":"user","content":"تحليل نسب التحويل لديّ"}],"context":{"totalProperties":0,"publishedCount":0,"totalViews":0,"totalLeads":0,"properties":[]},"lang":"ar"}}	\N	2026-06-04 00:36:57.06148	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
64	\N	POST /rkz/suggest-price	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/suggest-price","actionType":"WRITE","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":{"type":"villa","city":"الرياض"}}	\N	2026-06-04 00:39:11.259469	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
65	\N	GET /rkz/auth/me	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 00:41:54.345045	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
66	\N	POST /rkz/auth/login	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/auth/login","actionType":"AUTH_LOGIN","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":{"phone":"+96611111111111"}}	\N	2026-06-04 00:46:48.266208	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
123	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:28:46.885703	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
67	\N	POST /rkz/assistant/chat	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/assistant/chat","actionType":"WRITE","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":{"messages":[{"role":"assistant","content":"مرحباً! أنا مساعد ركز الذكي ✨\\n\\nمحفظتك تضم **0** عقارات، 0 منها منشورة مع **٠** مشاهدة و**0** مستفسر.\\n\\nاسألني عن أداء عقاراتك، التسعير، استراتيجية النشر، أو أي شيء عن السوق السعودي."},{"role":"user","content":"ما أفضل وقت للبيع في الرياض؟"}],"context":{"totalProperties":0,"publishedCount":0,"totalViews":0,"totalLeads":0,"properties":[]},"lang":"ar"}}	\N	2026-06-04 00:47:07.553499	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
68	\N	POST /rkz/generate-description	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/generate-description","actionType":"WRITE","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":{"type":"villa","city":"الرياض"}}	\N	2026-06-04 00:48:01.081263	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
69	\N	POST /rkz/suggest-price	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/suggest-price","actionType":"WRITE","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":{"type":"villa","city":"الرياض"}}	\N	2026-06-04 00:48:57.903969	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
70	\N	POST /rkz/listings	api_request	\N	{"statusCode":201,"endpointUrl":"/api/rkz/listings","actionType":"WRITE","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":{"type":"villa","price":20,"currency":"SAR","city":"الرياض","district":"امارة منطقة الرياض","address":"امارة منطقة الرياض","area":250,"bedrooms":258,"photos":[]}}	\N	2026-06-04 00:49:52.434013	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
71	\N	POST /rkz/match-buyers	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/match-buyers","actionType":"WRITE","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":{"type":"villa","city":"الرياض","price":20,"area":250,"bedrooms":258}}	\N	2026-06-04 00:49:52.659258	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
103	\N	POST /rkz/auth/login	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/auth/login","actionType":"AUTH_LOGIN","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":{"phone":"+966111111111"}}	\N	2026-06-04 02:24:46.94636	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
104	\N	POST /rkz/admin/verify-pin	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/admin/verify-pin","actionType":"WRITE","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":{"pin":"1234"}}	\N	2026-06-04 02:25:46.302868	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
105	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:25:46.783688	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
106	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:25:47.578679	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
107	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:25:47.580254	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
108	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:26:16.829989	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
109	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:26:16.832598	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
110	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:26:16.846698	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
111	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:26:46.874319	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
112	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:26:46.87637	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
113	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:26:46.886681	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
114	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:27:16.842725	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
115	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:27:16.844035	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
116	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:27:16.846232	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
117	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:27:46.815141	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
118	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:27:46.817023	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
119	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:27:46.827853	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
120	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:28:16.843599	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
121	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:28:16.844771	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
122	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:28:16.855123	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
125	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:28:46.896908	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
126	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:29:16.862251	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
127	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:29:16.863339	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
130	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:29:46.88933	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
135	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:30:23.294121	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
136	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:30:53.267451	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
128	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:29:16.866197	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
129	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:29:46.887666	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
131	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:29:46.899359	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
132	\N	POST /rkz/admin/verify-pin	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/admin/verify-pin","actionType":"WRITE","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":{"pin":"1234"}}	\N	2026-06-04 02:30:22.860213	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
133	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:30:23.230006	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
134	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:30:23.292389	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
137	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:30:53.270688	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
138	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:30:53.280278	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
139	\N	POST /rkz/admin/verify-pin	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/admin/verify-pin","actionType":"WRITE","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":{"pin":"1234"}}	\N	2026-06-04 02:31:11.669085	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
140	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:31:12.178809	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
141	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:31:12.181257	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
142	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:31:12.185137	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
143	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:31:42.200729	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
144	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:31:42.20091	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
145	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:31:42.211698	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
146	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:32:12.198094	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
147	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:32:12.201584	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
148	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:32:12.202003	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
149	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:32:42.212636	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
150	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:32:42.213368	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
151	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:32:42.223666	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
152	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:33:12.21783	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
153	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:33:12.222812	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
154	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:33:12.238329	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
155	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:33:42.243011	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
156	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:33:42.244285	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
157	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:33:42.25439	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
158	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:34:12.223829	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
159	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:34:12.226237	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
160	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:34:12.227683	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
161	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:34:42.255169	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
162	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:34:42.257991	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
163	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:34:42.259985	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
164	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:35:12.274715	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
165	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:35:12.27664	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
166	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:35:12.286509	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
167	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:35:43.022334	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
168	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:35:43.023773	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
169	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:35:43.03383	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
170	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:36:12.286976	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
171	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:36:12.288319	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
172	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:36:12.772762	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
173	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:36:42.99589	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
174	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:36:43.027773	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
175	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:36:43.157216	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
176	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:37:12.285662	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
177	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:37:12.286449	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
178	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 02:37:12.296573	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
179	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 02:38:18.981813	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
180	\N	GET /settings	api_request	\N	{"statusCode":401,"endpointUrl":"/api/settings","actionType":"SETTINGS_CHANGE","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 02:38:19.436647	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
181	\N	auth.login	user	1	\N	\N	2026-06-04 02:39:12.690066	Administrator	owner	admin	\N	\N	1	\N	\N	\N	1	\N	\N
182	\N	POST /auth/login	api_request	\N	{"statusCode":200,"endpointUrl":"/api/auth/login","actionType":"AUTH_LOGIN","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":{"username":"admin","password":"[REDACTED]"}}	\N	2026-06-04 02:39:12.690086	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
183	\N	GET /settings	api_request	\N	{"statusCode":200,"endpointUrl":"/api/settings","actionType":"SETTINGS_CHANGE","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":"owner","bodySnapshot":null}	\N	2026-06-04 02:39:12.959326	\N	\N	\N	\N	\N	1	\N	\N	\N	1	\N	\N
184	\N	GET /settings	api_request	\N	{"statusCode":304,"endpointUrl":"/api/settings","actionType":"SETTINGS_CHANGE","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":"owner","bodySnapshot":null}	\N	2026-06-04 02:39:30.839786	\N	\N	\N	\N	\N	1	\N	\N	\N	1	\N	\N
185	\N	GET /settings	api_request	\N	{"statusCode":304,"endpointUrl":"/api/settings","actionType":"SETTINGS_CHANGE","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":"owner","bodySnapshot":null}	\N	2026-06-04 02:40:23.914379	\N	\N	\N	\N	\N	1	\N	\N	\N	1	\N	\N
214	\N	GET /rkz/portal/auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/rkz/portal/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":null}	\N	2026-06-04 03:23:39.0466	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
215	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 03:24:17.793667	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
216	\N	POST /rkz/auth/login	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/auth/login","actionType":"AUTH_LOGIN","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":{"phone":"+966111111111"}}	\N	2026-06-04 03:50:19.219077	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
217	\N	POST /rkz/admin/verify-pin	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/admin/verify-pin","actionType":"WRITE","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":{"pin":"1234"}}	\N	2026-06-04 03:50:38.466508	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
218	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 03:50:38.955844	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
219	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 03:50:39.606187	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
220	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 03:50:39.614785	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
221	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 03:51:09.008577	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
222	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 03:51:09.012078	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
223	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 03:51:09.014857	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
224	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 03:51:39.063331	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
225	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 03:51:39.06523	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
226	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 03:51:39.075711	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
227	\N	GET /rkz/admin/buyer-intents	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/buyer-intents?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 03:52:09.06409	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
228	\N	GET /rkz/admin/chat-log	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/chat-log?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 03:52:09.065304	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
229	\N	GET /rkz/admin/violations	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/admin/violations?pin=1234","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":null}	\N	2026-06-04 03:52:09.066547	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
230	\N	GET /auth/me	api_request	\N	{"statusCode":200,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 03:53:24.115758	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
231	\N	POST /rkz/auth/login	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/auth/login","actionType":"AUTH_LOGIN","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":{"phone":"+966222222222"}}	\N	2026-06-04 04:09:42.875736	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
232	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 04:51:40.972537	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
233	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 05:06:35.571069	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
234	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 05:11:58.776222	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
235	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 05:12:37.545284	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
236	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 05:12:43.68319	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
237	\N	auth.login	user	1	\N	\N	2026-06-04 05:13:49.702415	Administrator	owner	admin	\N	\N	1	\N	\N	\N	1	\N	\N
238	\N	POST /auth/login	api_request	\N	{"statusCode":200,"endpointUrl":"/api/auth/login","actionType":"AUTH_LOGIN","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":{"username":"admin","password":"[REDACTED]"}}	\N	2026-06-04 05:13:49.702577	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
239	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 05:21:18.394245	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
240	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 05:24:27.426672	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
241	\N	POST /portal/auth/login-step1	api_request	\N	{"statusCode":401,"endpointUrl":"/api/portal/auth/login-step1","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"identifier":"wronguser@test.com","password":"[REDACTED]"}}	\N	2026-06-04 05:27:44.346069	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
242	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 05:27:47.468064	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
243	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 05:27:48.628845	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
244	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 05:28:09.04206	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
245	\N	POST /portal/auth/webauthn/authenticate-options	api_request	\N	{"statusCode":200,"endpointUrl":"/api/portal/auth/webauthn/authenticate-options","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"identifier":"nonexistent"}}	\N	2026-06-04 05:28:25.021004	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
246	\N	GET /portal/auth/webauthn/credentials	api_request	\N	{"statusCode":401,"endpointUrl":"/api/portal/auth/webauthn/credentials","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":null}	\N	2026-06-04 05:28:26.126187	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
247	\N	POST /rkz/auth/login	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/auth/login","actionType":"AUTH_LOGIN","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":{"phone":"+9661111111111"}}	\N	2026-06-04 05:50:38.523088	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
248	\N	POST /rkz/auth/login	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/auth/login","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"phone":"+966501234567","email":"test@example.com"}}	\N	2026-06-04 05:55:46.066065	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
249	\N	POST /rkz/auth/login	api_request	\N	{"statusCode":400,"endpointUrl":"/api/rkz/auth/login","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"phone":"+966501234567"}}	\N	2026-06-04 05:55:46.553439	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
250	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 11:15:46.456511	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
251	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 11:30:47.180731	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
252	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 11:32:29.412146	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
253	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 11:32:36.748383	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
254	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 11:34:10.502222	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
255	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 11:34:12.747917	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
256	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 11:35:12.569344	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
257	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 11:41:01.727047	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
258	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 11:44:44.018523	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
259	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 12:14:18.745014	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
260	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 12:14:58.195647	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
261	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 12:15:09.171256	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
262	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 12:15:13.39717	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
263	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 12:38:20.778449	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
264	\N	POST /rkz/auth/login	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/auth/login","actionType":"AUTH_LOGIN","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":{"phone":"+966543153957","email":"nofabark@gmail.com"}}	\N	2026-06-04 13:03:52.459308	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
265	\N	POST /rkz/auth/verify-otp	api_request	\N	{"statusCode":400,"endpointUrl":"/api/rkz/auth/verify-otp","actionType":"WRITE","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":{"pendingKey":"d115bccd-7dee-4f1f-be62-5df6b6dfefb6","otp":"000000"}}	\N	2026-06-04 13:04:03.207851	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
266	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 13:06:01.216303	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
267	\N	POST /rkz/auth/login	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/auth/login","actionType":"AUTH_LOGIN","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":{"phone":"+966222222222","email":"nofabark@gmail.com"}}	\N	2026-06-04 13:32:47.360629	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
268	\N	POST /rkz/auth/verify-otp	api_request	\N	{"statusCode":400,"endpointUrl":"/api/rkz/auth/verify-otp","actionType":"WRITE","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":{"pendingKey":"ff215718-0ff0-42ad-ae54-e612008d9e0a","otp":"222222"}}	\N	2026-06-04 13:32:50.725526	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
269	\N	POST /rkz/auth/verify-otp	api_request	\N	{"statusCode":400,"endpointUrl":"/api/rkz/auth/verify-otp","actionType":"WRITE","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":{"pendingKey":"ff215718-0ff0-42ad-ae54-e612008d9e0a","otp":"000000"}}	\N	2026-06-04 13:32:57.637449	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
270	\N	POST /rkz/auth/verify-otp	api_request	\N	{"statusCode":400,"endpointUrl":"/api/rkz/auth/verify-otp","actionType":"WRITE","deviceSource":"app","ip":"127.0.0.1","userAgent":"okhttp/4.12.0","role":null,"bodySnapshot":{"pendingKey":"ff215718-0ff0-42ad-ae54-e612008d9e0a","otp":"123456"}}	\N	2026-06-04 13:33:12.38476	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
271	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 15:12:57.985707	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
272	\N	POST /rkz/auth/login	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/auth/login","actionType":"AUTH_LOGIN","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":{"phone":"+966555555555555","email":"g.y.s.b444@gmail.com"}}	\N	2026-06-04 15:14:41.32722	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
273	\N	POST /portal/register	api_request	\N	{"statusCode":200,"endpointUrl":"/api/portal/register","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"displayName":"Email Test User","email":"test-email-probe@example.com","username":"emailtestprobe99","password":"[REDACTED]"}}	\N	2026-06-04 15:28:31.193365	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
274	\N	POST /portal/register	api_request	\N	{"statusCode":409,"endpointUrl":"/api/portal/register","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"displayName":"Email Test User","email":"test-email-probe@example.com","username":"emailtestprobe99","password":"[REDACTED]"}}	\N	2026-06-04 15:28:40.865271	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
275	\N	POST /portal/register	api_request	\N	{"statusCode":200,"endpointUrl":"/api/portal/register","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"displayName":"Sender Test","email":"test-sender-probe@mailinator.com","username":"sendertestprobe_x7","password":"[REDACTED]"}}	\N	2026-06-04 15:29:13.617398	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
276	\N	POST /rkz/auth/login	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/auth/login","actionType":"AUTH_LOGIN","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":{"phone":"+966543153957","email":"nofabark@gmail.com"}}	\N	2026-06-04 16:38:41.629801	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
277	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 18:50:35.635886	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
278	\N	POST /debug/test-email	api_request	\N	{"statusCode":200,"endpointUrl":"/api/debug/test-email?to=nofabark@hotmail.com","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":null}	\N	2026-06-04 19:12:14.140575	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
279	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 20:47:09.004951	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
280	\N	POST /ai-governance/kill-switch	api_request	\N	{"statusCode":401,"endpointUrl":"/api/ai-governance/kill-switch","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"active":false}}	\N	2026-06-04 20:47:21.835308	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
281	\N	POST /auth/login	api_request	\N	{"statusCode":400,"endpointUrl":"/api/auth/login","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"email":"admin@grandpms.com","password":"[REDACTED]","tenantSlug":"grand"}}	\N	2026-06-04 20:56:29.023694	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
282	\N	auth.login	user	1	\N	\N	2026-06-04 20:57:41.171246	Administrator	owner	admin	\N	\N	1	\N	\N	\N	1	\N	\N
283	\N	POST /auth/login	api_request	\N	{"statusCode":200,"endpointUrl":"/api/auth/login","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"username":"admin","password":"[REDACTED]","tenantSlug":"rakez"}}	\N	2026-06-04 20:57:41.171586	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
284	\N	POST /ai-governance/kill-switch	api_request	\N	{"statusCode":200,"endpointUrl":"/api/ai-governance/kill-switch","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":"owner","bodySnapshot":{"active":true}}	\N	2026-06-04 20:57:55.648502	\N	\N	\N	\N	\N	1	\N	\N	\N	1	\N	\N
285	\N	POST /ai-governance/action-queue	api_request	\N	{"statusCode":423,"endpointUrl":"/api/ai-governance/action-queue","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":"owner","bodySnapshot":{"actionType":"stress-test","targetEntity":"rooms","description":"Stress test action 1","proposedBy":"test-runner"}}	\N	2026-06-04 20:57:55.700446	\N	\N	\N	\N	\N	1	\N	\N	\N	1	\N	\N
286	\N	POST /ai-governance/action-queue	api_request	\N	{"statusCode":423,"endpointUrl":"/api/ai-governance/action-queue","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":"owner","bodySnapshot":{"actionType":"stress-test","targetEntity":"rooms","description":"Stress test action 2","proposedBy":"test-runner"}}	\N	2026-06-04 20:57:55.751053	\N	\N	\N	\N	\N	1	\N	\N	\N	1	\N	\N
287	\N	POST /ai-governance/action-queue	api_request	\N	{"statusCode":423,"endpointUrl":"/api/ai-governance/action-queue","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":"owner","bodySnapshot":{"actionType":"stress-test","targetEntity":"rooms","description":"Stress test action 3","proposedBy":"test-runner"}}	\N	2026-06-04 20:57:55.798976	\N	\N	\N	\N	\N	1	\N	\N	\N	1	\N	\N
288	\N	POST /ai-governance/action-queue	api_request	\N	{"statusCode":423,"endpointUrl":"/api/ai-governance/action-queue","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":"owner","bodySnapshot":{"actionType":"stress-test","targetEntity":"rooms","description":"Stress test action 4","proposedBy":"test-runner"}}	\N	2026-06-04 20:57:55.847948	\N	\N	\N	\N	\N	1	\N	\N	\N	1	\N	\N
289	\N	POST /ai-governance/action-queue	api_request	\N	{"statusCode":423,"endpointUrl":"/api/ai-governance/action-queue","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":"owner","bodySnapshot":{"actionType":"stress-test","targetEntity":"rooms","description":"Stress test action 5","proposedBy":"test-runner"}}	\N	2026-06-04 20:57:55.896058	\N	\N	\N	\N	\N	1	\N	\N	\N	1	\N	\N
290	\N	POST /ai-governance/action-queue	api_request	\N	{"statusCode":423,"endpointUrl":"/api/ai-governance/action-queue","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":"owner","bodySnapshot":{"actionType":"stress-test","targetEntity":"rooms","description":"Stress test action 1","proposedBy":"test-runner"}}	\N	2026-06-04 20:57:55.945289	\N	\N	\N	\N	\N	1	\N	\N	\N	1	\N	\N
291	\N	POST /ai-governance/action-queue	api_request	\N	{"statusCode":423,"endpointUrl":"/api/ai-governance/action-queue","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":"owner","bodySnapshot":{"actionType":"stress-test","targetEntity":"rooms","description":"Stress test action 2","proposedBy":"test-runner"}}	\N	2026-06-04 20:57:56.044531	\N	\N	\N	\N	\N	1	\N	\N	\N	1	\N	\N
292	\N	POST /ai-governance/action-queue	api_request	\N	{"statusCode":423,"endpointUrl":"/api/ai-governance/action-queue","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":"owner","bodySnapshot":{"actionType":"stress-test","targetEntity":"rooms","description":"Stress test action 3","proposedBy":"test-runner"}}	\N	2026-06-04 20:57:56.141339	\N	\N	\N	\N	\N	1	\N	\N	\N	1	\N	\N
293	\N	POST /ai-governance/action-queue	api_request	\N	{"statusCode":423,"endpointUrl":"/api/ai-governance/action-queue","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":"owner","bodySnapshot":{"actionType":"stress-test","targetEntity":"rooms","description":"Stress test action 4","proposedBy":"test-runner"}}	\N	2026-06-04 20:57:56.239389	\N	\N	\N	\N	\N	1	\N	\N	\N	1	\N	\N
294	\N	POST /ai-governance/action-queue	api_request	\N	{"statusCode":423,"endpointUrl":"/api/ai-governance/action-queue","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":"owner","bodySnapshot":{"actionType":"stress-test","targetEntity":"rooms","description":"Stress test action 5","proposedBy":"test-runner"}}	\N	2026-06-04 20:57:56.366422	\N	\N	\N	\N	\N	1	\N	\N	\N	1	\N	\N
295	\N	POST /ai-governance/kill-switch	api_request	\N	{"statusCode":200,"endpointUrl":"/api/ai-governance/kill-switch","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":"owner","bodySnapshot":{"active":false}}	\N	2026-06-04 20:57:56.484062	\N	\N	\N	\N	\N	1	\N	\N	\N	1	\N	\N
296	\N	POST /ai-governance/action-queue	api_request	\N	{"statusCode":201,"endpointUrl":"/api/ai-governance/action-queue","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":"owner","bodySnapshot":{"actionType":"UPDATE_ROOM_PRICE","targetEntity":"rooms","targetId":5,"description":"Increase Room 101 nightly rate by 12% based on occupancy trend analysis","payload":{"currentPrice":750,"proposedPrice":840,"confidence":0.87},"proposedBy":"ai-pricing-engine-v1"}}	\N	2026-06-04 20:58:01.301591	\N	\N	\N	\N	\N	1	\N	\N	\N	1	\N	\N
297	\N	DELETE /api/ai-governance/audit-log/1	api_request	\N	{"statusCode":404,"endpointUrl":"/api/ai-governance/audit-log/1","actionType":"DELETE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":"owner","bodySnapshot":null}	\N	2026-06-04 20:58:06.73369	\N	\N	\N	\N	\N	1	\N	\N	\N	1	\N	\N
298	\N	DELETE /api/ai-governance/audit-log	api_request	\N	{"statusCode":404,"endpointUrl":"/api/ai-governance/audit-log","actionType":"DELETE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":"owner","bodySnapshot":null}	\N	2026-06-04 20:58:06.783026	\N	\N	\N	\N	\N	1	\N	\N	\N	1	\N	\N
299	\N	PUT /api/ai-governance/audit-log/1	api_request	\N	{"statusCode":404,"endpointUrl":"/api/ai-governance/audit-log/1","actionType":"UPDATE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":"owner","bodySnapshot":{"description":"TAMPERED"}}	\N	2026-06-04 20:58:06.831501	\N	\N	\N	\N	\N	1	\N	\N	\N	1	\N	\N
300	\N	PATCH /api/ai-governance/audit-log/1	api_request	\N	{"statusCode":404,"endpointUrl":"/api/ai-governance/audit-log/1","actionType":"UPDATE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":"owner","bodySnapshot":{"description":"TAMPERED"}}	\N	2026-06-04 20:58:06.881987	\N	\N	\N	\N	\N	1	\N	\N	\N	1	\N	\N
301	\N	PATCH /ai-governance/action-queue/1	api_request	\N	{"statusCode":200,"endpointUrl":"/api/ai-governance/action-queue/1","actionType":"UPDATE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":"owner","bodySnapshot":{"decision":"approved","note":"Validated by governance test — occupancy data confirmed"}}	\N	2026-06-04 20:58:21.909844	\N	\N	\N	\N	\N	1	\N	\N	\N	1	\N	\N
302	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 21:18:03.598107	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
303	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 21:18:16.809572	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
304	\N	POST /portal/auth/login-step1	api_request	\N	{"statusCode":200,"endpointUrl":"/api/portal/auth/login-step1","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"identifier":"admin@grandpms.io","password":"[REDACTED]"}}	\N	2026-06-04 21:18:33.860524	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
305	\N	POST /portal/auth/login-step1	api_request	\N	{"statusCode":200,"endpointUrl":"/api/portal/auth/login-step1","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"identifier":"admin@grandpms.io","password":"[REDACTED]"}}	\N	2026-06-04 21:18:34.469834	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
306	\N	POST /portal/auth/login-step1	api_request	\N	{"statusCode":200,"endpointUrl":"/api/portal/auth/login-step1","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"undici","role":null,"bodySnapshot":{"identifier":"admin@grandpms.io","password":"[REDACTED]"}}	\N	2026-06-04 21:18:43.492329	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
307	\N	GET /api/portal/auth/me	api_request	\N	{"statusCode":404,"endpointUrl":"/api/portal/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":null}	\N	2026-06-04 21:19:44.555697	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
308	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 21:20:07.239432	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
309	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 21:33:43.519889	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
310	\N	GET /auth/me	api_request	\N	{"statusCode":200,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":null}	\N	2026-06-04 21:36:48.462639	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
311	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 21:37:31.077061	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
312	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 21:39:57.24492	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
313	\N	POST /rkz/auth/login	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/auth/login","actionType":"AUTH_LOGIN","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":{"phone":"+966543153957","email":"nofabark@gmail.com"}}	\N	2026-06-04 23:23:51.131834	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
314	\N	POST /rkz/auth/verify-otp	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/auth/verify-otp","actionType":"WRITE","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":{"pendingKey":"af1b4d3c-c280-4ff2-bcd3-453762204a18","otp":"935649"}}	\N	2026-06-04 23:25:21.15265	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
315	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 23:27:53.939178	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
316	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 23:28:16.356777	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
317	\N	GET /rkz/auth/me	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-04 23:29:19.465801	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
318	\N	GET /rkz/auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 06:55:33.058689	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
319	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 06:56:08.423934	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
320	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 06:56:46.626928	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
321	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 06:56:55.419856	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
322	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 06:57:05.188517	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
323	\N	POST /portal/auth/login-step1	api_request	\N	{"statusCode":200,"endpointUrl":"/api/portal/auth/login-step1","actionType":"AUTH_LOGIN","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":{"identifier":"admin","password":"[REDACTED]"}}	\N	2026-06-05 06:58:33.840592	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
324	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 07:08:27.204919	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
325	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 07:09:08.296318	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
326	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 07:12:24.470587	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
327	\N	POST /portal/auth/login-step1	api_request	\N	{"statusCode":200,"endpointUrl":"/api/portal/auth/login-step1","actionType":"AUTH_LOGIN","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":{"identifier":"admin","password":"[REDACTED]"}}	\N	2026-06-05 07:12:51.139151	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
328	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 07:14:12.792777	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
329	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 07:18:28.040209	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
330	\N	POST /portal/auth/login-step1	api_request	\N	{"statusCode":200,"endpointUrl":"/api/portal/auth/login-step1","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"identifier":"admin","password":"[REDACTED]"}}	\N	2026-06-05 08:59:08.424742	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
331	\N	POST /portal/auth/login-step1	api_request	\N	{"statusCode":200,"endpointUrl":"/api/portal/auth/login-step1","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"identifier":"admin","password":"[REDACTED]"}}	\N	2026-06-05 08:59:14.213503	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
332	\N	POST /portal/auth/login-step1	api_request	\N	{"statusCode":200,"endpointUrl":"/api/portal/auth/login-step1","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"identifier":"admin","password":"[REDACTED]"}}	\N	2026-06-05 08:59:22.594829	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
333	\N	POST /portal/auth/login-step2	api_request	\N	{"statusCode":200,"endpointUrl":"/api/portal/auth/login-step2","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"pendingToken":"8d6754fc-bef5-4f6c-a337-3a31f322e509","otp":"000000"}}	\N	2026-06-05 08:59:22.663795	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
334	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:01:39.911362	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
335	\N	GET /rkz/auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:02:14.614002	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
336	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:05:42.193298	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
337	\N	POST /portal/auth/login-step1	api_request	\N	{"statusCode":401,"endpointUrl":"/api/portal/auth/login-step1","actionType":"AUTH_LOGIN","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":{"identifier":"admin","password":"[REDACTED]"}}	\N	2026-06-05 09:06:19.147209	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
338	\N	POST /auth/change-password	api_request	\N	{"statusCode":400,"endpointUrl":"/api/auth/change-password","actionType":"AUTH_PASSWORD_CHANGE","deviceSource":"web","ip":"127.0.0.1","userAgent":"undici","role":null,"bodySnapshot":{"currentPassword":"admin123","newPassword":"[REDACTED]"}}	\N	2026-06-05 09:06:19.151101	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
339	\N	POST /auth/change-password	api_request	\N	{"statusCode":200,"endpointUrl":"/api/auth/change-password","actionType":"AUTH_PASSWORD_CHANGE","deviceSource":"web","ip":"127.0.0.1","userAgent":"undici","role":null,"bodySnapshot":{"currentPassword":"admin123","newPassword":"[REDACTED]"}}	\N	2026-06-05 09:06:42.041175	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
340	\N	POST /portal/auth/login-step1	api_request	\N	{"statusCode":401,"endpointUrl":"/api/portal/auth/login-step1","actionType":"AUTH_LOGIN","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":{"identifier":"0500000000","password":"[REDACTED]"}}	\N	2026-06-05 09:06:47.456897	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
341	\N	POST /portal/auth/login-step1	api_request	\N	{"statusCode":200,"endpointUrl":"/api/portal/auth/login-step1","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"identifier":"admin","password":"[REDACTED]"}}	\N	2026-06-05 09:06:57.914192	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
342	\N	POST /portal/auth/login-step2	api_request	\N	{"statusCode":200,"endpointUrl":"/api/portal/auth/login-step2","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"pendingToken":"a063eddd-8ba5-4556-b599-30a606308c27","otp":"000000"}}	\N	2026-06-05 09:06:58.029062	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
343	\N	POST /portal/auth/login-step1	api_request	\N	{"statusCode":200,"endpointUrl":"/api/portal/auth/login-step1","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"identifier":"admin@rkz.info","password":"[REDACTED]"}}	\N	2026-06-05 09:06:58.124215	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
344	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:08:29.972971	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
345	\N	POST /portal/auth/login-step1	api_request	\N	{"statusCode":200,"endpointUrl":"/api/portal/auth/login-step1","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"identifier":"admin","password":"[REDACTED]"}}	\N	2026-06-05 09:13:27.793147	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
346	\N	POST /portal/auth/login-step1	api_request	\N	{"statusCode":200,"endpointUrl":"/api/portal/auth/login-step1","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"identifier":"admin@rkz.info","password":"[REDACTED]"}}	\N	2026-06-05 09:13:27.85405	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
347	\N	GET /rkz/auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:14:20.316031	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
348	\N	POST /portal/auth/login-step1	api_request	\N	{"statusCode":200,"endpointUrl":"/api/portal/auth/login-step1","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"identifier":"admin","password":"[REDACTED]"}}	\N	2026-06-05 09:15:50.016384	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
349	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:15:52.836538	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
372	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:32:09.381923	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
350	\N	POST /rkz/auth/login	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/auth/login","actionType":"AUTH_LOGIN","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":{"phone":"+9665000000000","email":"admin@rkz.info"}}	\N	2026-06-05 09:16:03.215692	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
351	\N	POST /rkz/auth/verify-otp	api_request	\N	{"statusCode":400,"endpointUrl":"/api/rkz/auth/verify-otp","actionType":"WRITE","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":{"pendingKey":"44fb4f62-7149-4f07-a98c-23e32533b7a0","otp":"000000"}}	\N	2026-06-05 09:16:10.383512	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
352	\N	POST /rkz/auth/verify-otp	api_request	\N	{"statusCode":400,"endpointUrl":"/api/rkz/auth/verify-otp","actionType":"WRITE","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":{"pendingKey":"44fb4f62-7149-4f07-a98c-23e32533b7a0","otp":"000000"}}	\N	2026-06-05 09:16:26.130069	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
353	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:20:42.616428	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
354	\N	POST /portal/auth/login-step1	api_request	\N	{"statusCode":200,"endpointUrl":"/api/portal/auth/login-step1","actionType":"AUTH_LOGIN","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":{"identifier":"admin","password":"[REDACTED]"}}	\N	2026-06-05 09:20:51.005911	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
355	\N	GET /auth/me	api_request	\N	{"statusCode":200,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:21:15.187456	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
356	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:21:26.590238	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
357	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:21:38.109674	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
358	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:22:07.103186	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
359	\N	POST /portal/auth/login-step1	api_request	\N	{"statusCode":200,"endpointUrl":"/api/portal/auth/login-step1","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"identifier":"admin","password":"[REDACTED]"}}	\N	2026-06-05 09:26:05.310471	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
360	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:27:00.166885	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
361	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/140.0.0.0 Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:27:13.962721	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
362	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:31:32.131435	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
363	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:31:38.967811	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
364	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:31:41.301281	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
365	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:31:43.942865	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
366	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:31:46.355808	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
367	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:31:48.723059	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
368	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:31:50.928638	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
369	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:31:53.161827	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
370	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:31:55.699074	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
371	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:32:03.564618	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
373	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:32:11.694032	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
374	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:32:14.171004	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
375	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:32:16.412969	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
376	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:32:18.595436	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
377	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:32:20.844656	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
378	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:32:23.202405	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
379	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 09:32:25.97671	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
380	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 12:06:54.591327	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
381	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 12:07:02.213969	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
382	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 12:07:04.672664	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
383	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 12:07:06.908296	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
384	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 12:07:09.260588	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
385	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 12:07:11.66059	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
386	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 12:07:14.020728	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
387	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 12:07:16.184887	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
388	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 12:07:18.505057	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
389	\N	GET /api/portal/auth/me	api_request	\N	{"statusCode":404,"endpointUrl":"/api/portal/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":null}	\N	2026-06-05 12:10:14.446927	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
390	\N	GET /rkz/auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 12:10:21.02232	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
391	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 12:10:30.62758	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
392	\N	GET /auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 12:10:56.223602	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
393	\N	POST /auth/change-password	api_request	\N	{"statusCode":200,"endpointUrl":"/api/auth/change-password","actionType":"AUTH_PASSWORD_CHANGE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"currentPassword":"adminadmin","newPassword":"[REDACTED]"}}	\N	2026-06-05 12:11:13.049692	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
394	\N	POST /portal/auth/login-step1	api_request	\N	{"statusCode":200,"endpointUrl":"/api/portal/auth/login-step1","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"identifier":"admin","password":"[REDACTED]"}}	\N	2026-06-05 12:11:13.11309	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
395	\N	GET /rkz/auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 12:24:39.464131	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
396	\N	GET /rkz/auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 12:24:56.06728	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
397	\N	GET /rkz/auth/me	api_request	\N	{"statusCode":304,"endpointUrl":"/api/rkz/auth/me","actionType":"READ","deviceSource":"app","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36","role":null,"bodySnapshot":null}	\N	2026-06-05 12:25:21.389078	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
398	\N	GET /auth/me	api_request	\N	{"statusCode":401,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":null}	\N	2026-06-05 18:11:57.733251	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
399	\N	POST /rkz/analysis	api_request	\N	{"statusCode":500,"endpointUrl":"/api/rkz/analysis","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":null}	\N	2026-06-06 11:09:36.660068	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
400	\N	POST /rkz/analysis	api_request	\N	{"statusCode":500,"endpointUrl":"/api/rkz/analysis","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":null}	\N	2026-06-06 11:09:46.371402	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
401	\N	POST /rkz/analysis	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/analysis","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"income":15000,"budget":500000,"propertyType":"apartment","city":"Riyadh","paymentPreference":"mortgage","existingCommitments":2000}}	\N	2026-06-06 11:10:56.008055	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
402	\N	POST /rkz/analysis	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/analysis","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"income":15000,"budget":500000,"propertyType":"apartment","city":"Riyadh","paymentPreference":"mortgage","existingCommitments":2000}}	\N	2026-06-06 11:12:06.931357	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
403	\N	POST /rkz/analysis	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/analysis","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"income":15000,"budget":500000,"propertyType":"apartment","city":"Riyadh","paymentPreference":"mortgage","existingCommitments":2000}}	\N	2026-06-06 11:13:31.51576	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
404	\N	POST /rkz/analysis	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/analysis","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"income":15000,"budget":500000,"propertyType":"apartment","city":"Riyadh","paymentPreference":"mortgage","existingCommitments":2000}}	\N	2026-06-06 11:14:40.95493	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
405	\N	POST /rkz/analysis-killswitch	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/analysis-killswitch","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"enabled":true}}	\N	2026-06-06 11:15:30.724897	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
406	\N	POST /rkz/analysis	api_request	\N	{"statusCode":423,"endpointUrl":"/api/rkz/analysis","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"income":15000,"budget":500000}}	\N	2026-06-06 11:15:30.905603	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
407	\N	POST /rkz/analysis-killswitch	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/analysis-killswitch","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"enabled":false}}	\N	2026-06-06 11:15:31.134992	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
408	\N	POST /rkz/analysis	api_request	\N	{"statusCode":200,"endpointUrl":"/api/rkz/analysis","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"income":20000,"budget":750000,"propertyType":"villa","city":"KAFD Riyadh","paymentPreference":"mortgage","existingCommitments":3000}}	\N	2026-06-06 11:54:36.030861	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
409	\N	POST /api/portal/auth/logout	api_request	\N	{"statusCode":404,"endpointUrl":"/api/portal/auth/logout","actionType":"AUTH_LOGOUT","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{}}	\N	2026-06-07 10:48:05.252031	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
410	\N	POST /portal/auth/login-step1	api_request	\N	{"statusCode":200,"endpointUrl":"/api/portal/auth/login-step1","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"identifier":"yousef","password":"[REDACTED]"}}	\N	2026-06-08 11:55:48.276783	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
411	\N	POST /preview/authenticate	api_request	\N	{"statusCode":404,"endpointUrl":"/api/preview/authenticate","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"token":"[REDACTED]"}}	\N	2026-06-08 19:23:17.606448	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
412	\N	auth.login	user	1	\N	\N	2026-06-08 19:23:35.535724	Administrator	owner	admin	\N	\N	1	\N	\N	\N	1	\N	\N
413	\N	POST /auth/login	api_request	\N	{"statusCode":200,"endpointUrl":"/api/auth/login","actionType":"AUTH_LOGIN","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"username":"admin","password":"[REDACTED]"}}	\N	2026-06-08 19:23:35.535792	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
414	\N	POST /api/preview/links	api_request	\N	{"statusCode":404,"endpointUrl":"/api/preview/links","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":"owner","bodySnapshot":{"portal":"grand-pms","label":"Test Guest Link","expiresIn":3600}}	\N	2026-06-08 19:23:35.600522	\N	\N	\N	\N	\N	1	\N	\N	\N	1	\N	\N
415	\N	POST /preview/authenticate	api_request	\N	{"statusCode":200,"endpointUrl":"/api/preview/authenticate","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"token":"[REDACTED]"}}	\N	2026-06-08 19:23:53.983153	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
416	\N	GET /auth/me	api_request	\N	{"statusCode":200,"endpointUrl":"/api/auth/me","actionType":"READ","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":null}	\N	2026-06-08 19:24:04.653532	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
417	\N	POST /preview/authenticate	api_request	\N	{"statusCode":410,"endpointUrl":"/api/preview/authenticate","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"curl/8.14.1","role":null,"bodySnapshot":{"token":"[REDACTED]"}}	\N	2026-06-08 19:24:04.699097	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
418	\N	POST /preview/authenticate	api_request	\N	{"statusCode":200,"endpointUrl":"/api/preview/authenticate","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0","role":null,"bodySnapshot":{"token":"[REDACTED]"}}	\N	2026-06-08 19:24:27.985483	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
419	\N	POST /preview/authenticate	api_request	\N	{"statusCode":200,"endpointUrl":"/api/preview/authenticate","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0","role":null,"bodySnapshot":{"token":"[REDACTED]"}}	\N	2026-06-08 19:25:44.369956	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
420	\N	POST /preview/authenticate	api_request	\N	{"statusCode":200,"endpointUrl":"/api/preview/authenticate","actionType":"WRITE","deviceSource":"web","ip":"127.0.0.1","userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0","role":null,"bodySnapshot":{"token":"[REDACTED]"}}	\N	2026-06-08 19:26:45.329395	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N
\.


--
-- Data for Name: ai_action_queue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_action_queue (id, tenant_id, action_type, target_entity, target_id, description, payload, proposed_by, status, reviewed_by_id, reviewed_by_name, review_note, reviewed_at, executed_at, created_at) FROM stdin;
1	1	UPDATE_ROOM_PRICE	rooms	5	Increase Room 101 nightly rate by 12% based on occupancy trend analysis	{"confidence": 0.87, "currentPrice": 750, "proposedPrice": 840}	ai-pricing-engine-v1	approved	\N	admin@grandpms.io	Validated by governance test — occupancy data confirmed	2026-06-04 20:58:21.901+00	2026-06-04 20:58:21.901+00	2026-06-04 20:58:01.29424+00
\.


--
-- Data for Name: ai_audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_audit_log (id, tenant_id, action_queue_id, event, actor_type, actor_id, actor_name, target_entity, target_id, description, before_state, after_state, metadata, ip_address, created_at) FROM stdin;
1	1	\N	KILL_SWITCH_ACTIVATED	human	\N	admin@grandpms.io	\N	\N	AI autonomous processing HALTED by administrator	{"active": false}	{"active": true}	\N	127.0.0.1	2026-06-04 20:57:55.64484+00
2	1	\N	KILL_SWITCH_DEACTIVATED	human	\N	admin@grandpms.io	\N	\N	AI autonomous processing RESUMED by administrator	{"active": true}	{"active": false}	\N	127.0.0.1	2026-06-04 20:57:56.480676+00
3	1	1	ACTION_PROPOSED	ai	\N	ai-pricing-engine-v1	rooms	5	Proposed action: Increase Room 101 nightly rate by 12% based on occupancy trend analysis	\N	{"id": 1, "status": "pending", "payload": {"confidence": 0.87, "currentPrice": 750, "proposedPrice": 840}, "targetId": 5, "tenantId": 1, "createdAt": "2026-06-04T20:58:01.294Z", "actionType": "UPDATE_ROOM_PRICE", "executedAt": null, "proposedBy": "ai-pricing-engine-v1", "reviewNote": null, "reviewedAt": null, "description": "Increase Room 101 nightly rate by 12% based on occupancy trend analysis", "reviewedById": null, "targetEntity": "rooms", "reviewedByName": null}	\N	127.0.0.1	2026-06-04 20:58:01.298448+00
4	1	1	ACTION_APPROVED	human	\N	admin@grandpms.io	rooms	5	APPROVED: Increase Room 101 nightly rate by 12% based on occupancy trend analysis — Note: Validated by governance test — occupancy data confirmed	{"id": 1, "status": "pending", "payload": {"confidence": 0.87, "currentPrice": 750, "proposedPrice": 840}, "targetId": 5, "tenantId": 1, "createdAt": "2026-06-04T20:58:01.294Z", "actionType": "UPDATE_ROOM_PRICE", "executedAt": null, "proposedBy": "ai-pricing-engine-v1", "reviewNote": null, "reviewedAt": null, "description": "Increase Room 101 nightly rate by 12% based on occupancy trend analysis", "reviewedById": null, "targetEntity": "rooms", "reviewedByName": null}	{"id": 1, "status": "approved", "payload": {"confidence": 0.87, "currentPrice": 750, "proposedPrice": 840}, "targetId": 5, "tenantId": 1, "createdAt": "2026-06-04T20:58:01.294Z", "actionType": "UPDATE_ROOM_PRICE", "executedAt": "2026-06-04T20:58:21.901Z", "proposedBy": "ai-pricing-engine-v1", "reviewNote": "Validated by governance test — occupancy data confirmed", "reviewedAt": "2026-06-04T20:58:21.901Z", "description": "Increase Room 101 nightly rate by 12% based on occupancy trend analysis", "reviewedById": null, "targetEntity": "rooms", "reviewedByName": "admin@grandpms.io"}	\N	127.0.0.1	2026-06-04 20:58:21.906098+00
\.


--
-- Data for Name: archiving_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.archiving_logs (id, tenant_id, run_at, triggered_by, status, datasets, records_archived, archive_keys, notes, snoozed_until, created_at) FROM stdin;
\.


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bookings (id, guest_name, guest_email, guest_phone, room_id, check_in, check_out, status, total_amount, notes, created_at, tenant_id, guest_id) FROM stdin;
1	Ahmed Al-Rashidi	ahmed@example.com	+966501111111	1	2026-05-01	2026-05-05	checked_out	1000.00	\N	2026-06-04 00:01:13.742556	1	\N
2	Sara Al-Qahtani	sara@example.com	+966502222222	2	2026-05-10	2026-05-14	checked_out	1800.00	\N	2026-06-04 00:01:13.742556	1	\N
3	Mohammed Al-Harbi	moh@example.com	+966503333333	3	2026-05-20	2026-05-25	checked_out	4000.00	\N	2026-06-04 00:01:13.742556	1	\N
4	Fatima Al-Dosari	fatima@example.com	+966504444444	4	2026-05-28	2026-06-03	checked_out	1920.00	\N	2026-06-04 00:01:13.742556	1	\N
5	Khalid Al-Otaibi	khalid@example.com	+966505555555	5	2026-06-01	2026-06-07	confirmed	3000.00	\N	2026-06-04 00:01:13.742556	1	\N
6	Noura Al-Ghamdi	noura@example.com	+966506666666	6	2026-06-02	2026-06-10	confirmed	9600.00	\N	2026-06-04 00:01:13.742556	1	\N
7	Abdullah Al-Zahrani	abdu@example.com	+966507777777	1	2026-06-05	2026-06-08	confirmed	750.00	\N	2026-06-04 00:01:13.742556	1	\N
8	Hessa Al-Mansouri	hessa@example.com	+966508888888	2	2026-04-15	2026-04-20	checked_out	2250.00	\N	2026-06-04 00:01:13.742556	1	\N
9	Tariq Al-Shammari	tariq@example.com	+966509999999	3	2026-04-22	2026-04-28	checked_out	4800.00	\N	2026-06-04 00:01:13.742556	1	\N
10	Reem Al-Sulami	reem@example.com	+966500000000	4	2026-03-10	2026-03-15	checked_out	1600.00	\N	2026-06-04 00:01:13.742556	1	\N
\.


--
-- Data for Name: company_reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company_reports (id, tenant_id, title, report_type, fiscal_year, fiscal_period, file_url, file_size_kb, published_at, created_at) FROM stdin;
\.


--
-- Data for Name: contracts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contracts (id, tenant_id, property_id, room_id, contract_number, tenant_name, tenant_phone, tenant_email, start_date, end_date, monthly_rent, deposit_amount, status, notes, created_at) FROM stdin;
1	1	1	1	CNT-2025-001	أحمد محمد السعيد	0501234567	ahmed@email.com	2025-01-01	2025-12-31	4500.00	9000.00	active	عقد سنوي — الدفع شهرياً	2026-06-09 14:18:59.991393
2	1	1	2	CNT-2025-002	فاطمة علي المنصور	0509876543	fatima@email.com	2025-03-01	2026-02-28	3800.00	7600.00	active	\N	2026-06-09 14:18:59.991393
3	1	2	5	CNT-2025-003	خالد عبدالله الرشيد	0555551234	\N	2025-02-15	2025-08-14	2900.00	5800.00	expired	تم تجديده — جاري الإعداد	2026-06-09 14:18:59.991393
4	1	2	6	CNT-2025-004	نورة سعد التميمي	0544447890	noura@email.com	2025-05-01	2026-04-30	3200.00	6400.00	active	\N	2026-06-09 14:18:59.991393
5	1	3	10	CNT-2025-005	محمد حسن القحطاني	0533339012	\N	2024-12-01	2025-05-31	5500.00	11000.00	terminated	إنهاء مبكر باتفاق الطرفين	2026-06-09 14:18:59.991393
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.conversations (id, title, agent_type, user_id, tenant_id, created_at) FROM stdin;
\.


--
-- Data for Name: custom_fields; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_fields (id, entity_type, field_key, field_label, field_type, options, required, sort_order, active, created_at, updated_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: custom_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_roles (id, tenant_id, name, description, color, permissions, created_at) FROM stdin;
\.


--
-- Data for Name: dividend_distributions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dividend_distributions (id, tenant_id, partner_id, amount, currency, distribution_date, status, fiscal_period, notes, created_at) FROM stdin;
\.


--
-- Data for Name: equity_stakes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.equity_stakes (id, tenant_id, user_id, total_company_shares, partner_share_count, valuation_per_share, currency, effective_date, updated_at) FROM stdin;
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.expenses (id, property_id, unit_id, title, category, amount, expense_date, notes, created_at, tenant_id) FROM stdin;
1	1	\N	Monthly HVAC service	maintenance	12000.00	2026-05-15	\N	2026-06-04 00:01:19.334307	1
2	1	\N	Electricity and water	utilities	8500.00	2026-05-30	\N	2026-06-04 00:01:19.334307	1
3	2	\N	Plumbing repairs	maintenance	4200.00	2026-05-20	\N	2026-06-04 00:01:19.334307	1
4	3	\N	Security staff May	salaries	6800.00	2026-05-31	\N	2026-06-04 00:01:19.334307	1
5	1	\N	Electricity April	utilities	9000.00	2026-04-30	\N	2026-06-04 00:01:19.334307	1
6	2	\N	Painting common areas	maintenance	3500.00	2026-04-10	\N	2026-06-04 00:01:19.334307	1
\.


--
-- Data for Name: field_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.field_users (id, name, role, email, phone, property_id, status, notes, created_at, updated_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: guest_feedback; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.guest_feedback (id, room_id, rating, comment, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: guest_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.guest_requests (id, room_id, type, description, facility_name, scheduled_at, visitor_name, visitor_phone, status, ref_code, created_at, tenant_id) FROM stdin;
1	\N	contact	test\n\n---\nEmail: t@t.com	t@t.com	\N	Test	\N	new	CNT-MPYDCCEG	2026-06-03 17:57:09.449754	1
2	\N	contact	Subject: استفسار شراكة\n\nطلب شراكة جديد مُقدَّم عبر الصفحة الرئيسية.\n\n---\nEmail: nofabar@gmail.com	nofabar@gmail.com	\N	ع	5	new	CNT-MPZFJ0B8	2026-06-04 11:46:05.782153	1
\.


--
-- Data for Name: guests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.guests (id, tenant_id, name, email, phone, created_at) FROM stdin;
\.


--
-- Data for Name: inventory_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory_items (id, tenant_id, name, category, quantity, min_quantity, unit, location, description, created_at, updated_at) FROM stdin;
1	1	مصباح LED 12W	electrical	45.00	10.00	piece	رف A1	مصابيح موفرة للطاقة	2026-06-09 14:18:59.991393	2026-06-09 14:18:59.991393
2	1	كابل كهربائي 2.5mm	electrical	120.00	20.00	meter	رف A2	\N	2026-06-09 14:18:59.991393	2026-06-09 14:18:59.991393
3	1	مفتاح كهرباء مفرد	electrical	8.00	15.00	piece	رف A3	مخزون منخفض	2026-06-09 14:18:59.991393	2026-06-09 14:18:59.991393
4	1	صنبور مياه مطبخ	plumbing	6.00	5.00	piece	رف B1	\N	2026-06-09 14:18:59.991393	2026-06-09 14:18:59.991393
5	1	أنبوب PVC 2 بوصة	plumbing	30.00	10.00	meter	رف B2	\N	2026-06-09 14:18:59.991393	2026-06-09 14:18:59.991393
6	1	سيليكون أبيض	plumbing	12.00	5.00	piece	رف B3	\N	2026-06-09 14:18:59.991393	2026-06-09 14:18:59.991393
7	1	فلتر مكيف هواء	hvac	3.00	8.00	piece	رف C1	مخزون منخفض — يجب الطلب	2026-06-09 14:18:59.991393	2026-06-09 14:18:59.991393
8	1	غاز فريون R410a	hvac	4.00	3.00	piece	رف C2	أسطوانات	2026-06-09 14:18:59.991393	2026-06-09 14:18:59.991393
9	1	منظف متعدد الأغراض	cleaning	20.00	10.00	liter	رف D1	\N	2026-06-09 14:18:59.991393	2026-06-09 14:18:59.991393
10	1	أكياس نفايات كبيرة	cleaning	3.00	10.00	box	رف D2	كل علبة 50 كيس — مخزون منخفض	2026-06-09 14:18:59.991393	2026-06-09 14:18:59.991393
11	1	مفك براغي كهربائي	tools	2.00	2.00	piece	رف E1	\N	2026-06-09 14:18:59.991393	2026-06-09 14:18:59.991393
12	1	معدة لحام	tools	1.00	1.00	piece	رف E2	\N	2026-06-09 14:18:59.991393	2026-06-09 14:18:59.991393
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoices (id, tenant_id, contract_id, property_id, room_id, invoice_number, tenant_name, amount, due_date, issued_date, status, notes, paid_at, created_at) FROM stdin;
1	1	1	1	1	INV-2025-001	أحمد محمد السعيد	4500.00	2025-06-10	2025-06-01	paid	\N	\N	2026-06-09 14:18:59.991393
2	1	1	1	1	INV-2025-002	أحمد محمد السعيد	4500.00	2025-07-10	2025-07-01	pending	\N	\N	2026-06-09 14:18:59.991393
3	1	2	1	2	INV-2025-003	فاطمة علي المنصور	3800.00	2025-06-10	2025-06-01	paid	\N	\N	2026-06-09 14:18:59.991393
4	1	2	1	2	INV-2025-004	فاطمة علي المنصور	3800.00	2025-07-10	2025-07-01	pending	\N	\N	2026-06-09 14:18:59.991393
5	1	4	2	6	INV-2025-005	نورة سعد التميمي	3200.00	2025-05-10	2025-05-01	overdue	متأخرة — التواصل بالهاتف	\N	2026-06-09 14:18:59.991393
6	1	\N	3	10	INV-2025-006	محمد حسن القحطاني	5500.00	2025-04-15	2025-04-01	cancelled	ملغاة بسبب إنهاء العقد	\N	2026-06-09 14:18:59.991393
\.


--
-- Data for Name: listing_inquiries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.listing_inquiries (id, tenant_id, listing_id, name, email, phone, message, source, status, created_at) FROM stdin;
\.


--
-- Data for Name: listings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.listings (id, tenant_id, property_id, title, description, listing_type, property_type, price, currency, area_sqm, bedrooms, bathrooms, floor, amenities, media, address, city, district, lat, lng, status, featured, view_count, contact_email, contact_phone, created_at, updated_at) FROM stdin;
1	1	\N	فيلا فاخرة - حي النرجس	فيلا راقية بتشطيبات عالية المستوى في أرقى أحياء الرياض، تتميز بمسبح خاص وحديقة واسعة	sale	villa	2850000.00	SAR	650.00	6	7	\N	["مسبح خاص","حديقة","مجلس","غرفة سائق","مصعد"]	[{"url":"https://images.unsplash.com/photo-1613977257363-707ba9348227?w=800","caption":"واجهة الفيلا"}]	حي النرجس، شارع الأمير سلطان	الرياض	النرجس	24.7750000	46.6523000	active	t	0	sales@rozoz.sa	+966500000001	2026-06-08 11:41:49.876857	2026-06-08 11:41:49.876857
2	1	\N	شقة راقية في حي الملقا	شقة فاخرة بإطلالة مميزة في حي الملقا الراقي، قريبة من المراكز التجارية والخدمات	sale	apartment	680000.00	SAR	220.00	4	3	\N	["صالة كبيرة","مطبخ مجهز","موقف سيارتين","أمن 24 ساعة"]	[{"url":"https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800","caption":"الصالة الرئيسية"}]	حي الملقا، شارع التخصصي	الرياض	الملقا	24.8012000	46.6389000	active	t	0	sales@rozoz.sa	+966500000002	2026-06-08 11:41:49.876857	2026-06-08 11:41:49.876857
3	1	\N	أرض تجارية - طريق الملك فهد	أرض تجارية ممتازة على طريق الملك فهد بموقع استراتيجي، مناسبة للمشاريع التجارية الكبرى	sale	commercial	4200000.00	SAR	1200.00	\N	\N	\N	["على شارع رئيسي","قريبة من المترو","منطقة تجارية"]	[{"url":"https://images.unsplash.com/photo-1486325212027-8081e485255e?w=800","caption":"موقع الأرض"}]	طريق الملك فهد، حي العليا	الرياض	العليا	24.6877000	46.7219000	active	f	0	sales@rozoz.sa	+966500000003	2026-06-08 11:41:49.876857	2026-06-08 11:41:49.876857
4	1	\N	فيلا بإطلالة بحرية - جدة	فيلا فاخرة على كورنيش جدة بإطلالة مباشرة على البحر الأحمر، تصميم عصري راقٍ	sale	villa	3950000.00	SAR	580.00	5	6	\N	["إطلالة بحرية","مسبح","شاطئ خاص","غرفة تسلية"]	[{"url":"https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800","caption":"إطلالة البحر"}]	كورنيش جدة الشمالي	جدة	الكورنيش	21.5433000	39.1728000	active	t	0	sales@rozoz.sa	+966500000004	2026-06-08 11:41:49.876857	2026-06-08 11:41:49.876857
5	1	\N	شقة مودرن في الدمام	شقة عصرية في قلب الدمام قريبة من الخدمات والمرافق، مناسبة للعائلات والمستثمرين	rent	apartment	42000.00	SAR	180.00	3	2	\N	["موقف سيارة","أمن","انترنت فايبر","مصعد"]	[{"url":"https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800","caption":"غرفة المعيشة"}]	حي الشاطئ، شارع الملك فيصل	الدمام	الشاطئ	26.4367000	50.1033000	active	f	0	sales@rozoz.sa	+966500000005	2026-06-08 11:41:49.876857	2026-06-08 11:41:49.876857
6	1	\N	معرض تجاري - حي المربع	معرض تجاري في موقع حيوي بحي المربع، مساحة واسعة مناسبة لمختلف أنواع التجارة	rent	commercial	120000.00	SAR	350.00	\N	\N	\N	["واجهة زجاجية","تكييف مركزي","مواقف وافرة","قريب من الدوائر الحكومية"]	[{"url":"https://images.unsplash.com/photo-1497366216548-37526070297c?w=800","caption":"المعرض من الخارج"}]	حي المربع، شارع الوزير	الرياض	المربع	24.6508000	46.7741000	active	f	0	sales@rozoz.sa	+966500000006	2026-06-08 11:41:49.876857	2026-06-08 11:41:49.876857
7	1	\N	فندق بوتيك - وسط الرياض	فندق بوتيك فاخر في قلب الرياض يضم 24 غرفة بمستوى 5 نجوم، فرصة استثمارية مميزة	sale	hotel	12500000.00	SAR	2800.00	24	24	\N	["24 غرفة فاخرة","مطعم","صالة لياقة","قاعة اجتماعات","موقف مغطى"]	[{"url":"https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800","caption":"ردهة الفندق"}]	وسط الرياض، حي العليا	الرياض	العليا	24.7136000	46.6753000	active	t	0	sales@rozoz.sa	+966500000007	2026-06-08 11:41:49.876857	2026-06-08 11:41:49.876857
8	1	\N	مجمع سكني - المدينة المنورة	مجمع سكني متكامل في المدينة المنورة قريب من المسجد النبوي، يضم 12 وحدة سكنية	sale	compound	8700000.00	SAR	3200.00	36	24	\N	["قرب المسجد النبوي","حراسة أمنية","مواقف واسعة","مساحات خضراء"]	[{"url":"https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=800","caption":"المجمع السكني"}]	حي العزيزية، المدينة المنورة	المدينة المنورة	العزيزية	24.4686000	39.6142000	active	t	0	sales@rozoz.sa	+966500000008	2026-06-08 11:41:49.876857	2026-06-08 11:41:49.876857
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, conversation_id, role, content, created_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, type, title, message, is_read, related_id, related_type, created_at, tenant_id, user_id, notif_key, message_params) FROM stdin;
\.


--
-- Data for Name: portal_properties; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.portal_properties (id, tenant_id, name, type, address, city, country, description, status, created_at) FROM stdin;
1	1	Rakez Residence Tower A	residential	King Fahd Road, Block 5	Riyadh	SA	\N	active	2026-06-04 21:36:56.948492
2	1	Sunset Business Centre	commercial	Olaya District, Suite 200	Riyadh	SA	\N	active	2026-06-04 21:36:56.948492
3	1	Oakwood Compound	compound	Al Malqa District	Riyadh	SA	\N	active	2026-06-04 21:36:56.948492
\.


--
-- Data for Name: portal_units; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.portal_units (id, tenant_id, portal_property_id, unit_number, floor, type, area, bedroom_count, bathroom_count, status, monthly_rent, notes, created_at) FROM stdin;
1	1	1	A-101	1	studio	42.00	0	1	occupied	3500.00	\N	2026-06-04 21:37:29.749456
2	1	1	A-102	1	studio	42.00	0	1	available	3500.00	\N	2026-06-04 21:37:29.749456
3	1	1	A-103	1	1br	65.00	1	1	occupied	5200.00	\N	2026-06-04 21:37:29.749456
4	1	1	A-201	2	1br	65.00	1	1	occupied	5200.00	\N	2026-06-04 21:37:29.749456
5	1	1	A-202	2	2br	88.00	2	2	available	7800.00	\N	2026-06-04 21:37:29.749456
6	1	1	A-203	2	2br	88.00	2	2	maintenance	7800.00	\N	2026-06-04 21:37:29.749456
7	1	1	A-301	3	2br	88.00	2	2	occupied	7800.00	\N	2026-06-04 21:37:29.749456
8	1	1	A-302	3	3br	120.00	3	2	available	11500.00	\N	2026-06-04 21:37:29.749456
9	1	1	A-401	4	penthouse	200.00	4	3	occupied	22000.00	\N	2026-06-04 21:37:29.749456
10	1	2	B-01	1	office	80.00	0	1	occupied	9000.00	\N	2026-06-04 21:37:29.749456
11	1	2	B-02	1	office	80.00	0	1	occupied	9000.00	\N	2026-06-04 21:37:29.749456
12	1	2	B-03	1	office	120.00	0	2	available	13500.00	\N	2026-06-04 21:37:29.749456
13	1	2	B-04	1	retail	60.00	0	1	available	7500.00	\N	2026-06-04 21:37:29.749456
14	1	2	B-11	2	office	200.00	0	3	occupied	28000.00	\N	2026-06-04 21:37:29.749456
15	1	2	B-12	2	conference	150.00	0	2	maintenance	0.00	\N	2026-06-04 21:37:29.749456
16	1	3	V-01	1	villa	350.00	5	4	occupied	35000.00	\N	2026-06-04 21:37:29.749456
17	1	3	V-02	1	villa	350.00	5	4	available	35000.00	\N	2026-06-04 21:37:29.749456
18	1	3	V-03	1	villa	280.00	4	3	occupied	28000.00	\N	2026-06-04 21:37:29.749456
19	1	3	V-04	1	villa	280.00	4	3	maintenance	28000.00	\N	2026-06-04 21:37:29.749456
20	1	3	V-05	1	villa	280.00	4	3	occupied	28000.00	\N	2026-06-04 21:37:29.749456
\.


--
-- Data for Name: preview_links; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.preview_links (id, token, portal, label, created_by, expires_at, revoked_at, created_at) FROM stdin;
1	ac5fb3bf-25f8-4584-8c95-a6a9ee576e89	rkz	فيلا اختبار	mobile	2026-06-08 07:45:56.497914+00	\N	2026-06-08 06:45:56.497914+00
2	7c9f54c9-1325-43f6-a1d4-8927ee63a01e	rkz	فيلا نموذج للعرض	mobile	2026-06-08 08:05:41.908591+00	\N	2026-06-08 07:05:41.908591+00
3	43ae8f24-1ae0-4da9-9972-922527e03487	rkz	test	يوسف	2026-06-08 19:53:34.205042+00	\N	2026-06-08 18:53:34.205042+00
4	5e409bf8-c119-4f5f-9af5-18804518e12e	rkz-app	test	mobile	2026-06-08 20:06:41.791208+00	\N	2026-06-08 19:06:41.791208+00
5	7fcd13dd-be49-4417-b2ed-7448f076fb19	grand-pms	Test Guest	Administrator	2026-06-08 20:23:46.062374+00	2026-06-08 19:23:53.974221+00	2026-06-08 19:23:46.062374+00
6	3882dec2-b0c3-45c0-a2a7-74c77809d6dc	grand-pms	UI Test	Administrator	2026-06-08 20:24:17.808209+00	2026-06-08 19:24:27.964737+00	2026-06-08 19:24:17.808209+00
7	03454522-b1a7-4588-8fe5-60d7b7091049	grand-pms	Final Test	Administrator	2026-06-08 20:25:37.086458+00	2026-06-08 19:25:44.353594+00	2026-06-08 19:25:37.086458+00
8	87675260-9a9d-41bd-9857-db445785f3ed	grand-pms	Final UI Test	Administrator	2026-06-08 20:26:38.712372+00	2026-06-08 19:26:45.312224+00	2026-06-08 19:26:38.712372+00
\.


--
-- Data for Name: properties; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.properties (id, name, address, city, country, description, status, created_at, tenant_id, type) FROM stdin;
1	Grand Hotel Downtown	King Fahd Road, Al Olaya	Riyadh	SA	\N	active	2026-06-03 23:59:49.492799	1	hotel
2	Sunset Apartments	Prince Sultan Street	Jeddah	SA	\N	active	2026-06-03 23:59:49.492799	1	apartment
3	Oakwood Compound	Dhahran Highway, Al Rawabi	Dammam	SA	\N	active	2026-06-03 23:59:49.492799	1	compound
\.


--
-- Data for Name: property_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.property_categories (id, tenant_id, slug, label_en, label_ar, icon, color, is_active, sort_order, created_at) FROM stdin;
1	1	hotel	Hotel	فندق	building-2	blue	t	1	2026-06-02 06:26:21.484862
2	1	apartment	Apartment	شقة	home	green	t	2	2026-06-02 06:26:21.484862
3	1	compound	Compound	مجمع	building	orange	t	3	2026-06-02 06:26:21.484862
4	1	villa	Villa	فيلا	landmark	purple	t	4	2026-06-02 06:26:21.484862
5	1	commercial	Commercial	تجاري	store	red	t	5	2026-06-02 06:26:21.484862
6	1	office	Office	مكتب	briefcase	slate	t	6	2026-06-02 06:26:21.484862
7	1	warehouse	Warehouse	مستودع	warehouse	amber	t	7	2026-06-02 06:26:21.484862
\.


--
-- Data for Name: rkz_listings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rkz_listings (id, user_id, type, price, currency, city, district, address, lat, lng, area, bedrooms, bathrooms, title, description, photos, platforms, status, featured, view_count, published_at, created_at, updated_at) FROM stdin;
1	1	villa	2850000.00	SAR	الرياض	النرجس	حي النرجس	24.7750000	46.6523000	450.00	6	7	فيلا فاخرة - حي النرجس	\N	[]	[]	active	f	0	2026-06-01 23:42:46.186786	2026-06-03 23:42:46.186786	2026-06-03 23:42:46.186786
2	1	apartment	680000.00	SAR	الرياض	الملقا	حي الملقا	24.8012000	46.6389000	180.00	3	3	شقة راقية في حي الملقا	\N	[]	[]	active	f	0	2026-06-02 23:42:46.186786	2026-06-03 23:42:46.186786	2026-06-03 23:42:46.186786
3	1	land	4200000.00	SAR	الرياض	العليا	طريق الملك فهد	24.6877000	46.7219000	800.00	\N	\N	أرض تجارية - طريق الملك فهد	\N	[]	[]	active	f	0	2026-06-03 18:42:46.186786	2026-06-03 23:42:46.186786	2026-06-03 23:42:46.186786
4	1	villa	1950000.00	SAR	جدة	الشاطئ	حي الشاطئ	21.5433000	39.1728000	380.00	5	5	فيلا بإطلالة بحرية - جدة	\N	[]	[]	active	f	0	2026-05-31 23:42:46.186786	2026-06-03 23:42:46.186786	2026-06-03 23:42:46.186786
5	1	apartment	420000.00	SAR	الدمام	الفيصلية	حي الفيصلية	26.4367000	50.1033000	130.00	2	2	شقة مودرن في الدمام	\N	[]	[]	active	f	0	2026-06-03 17:42:46.186786	2026-06-03 23:42:46.186786	2026-06-03 23:42:46.186786
6	1	commercial	3100000.00	SAR	الرياض	المربع	حي المربع	24.6508000	46.7741000	600.00	\N	\N	معرض تجاري - حي المربع	\N	[]	[]	active	f	0	2026-06-03 11:42:46.186786	2026-06-03 23:42:46.186786	2026-06-03 23:42:46.186786
7	4	villa	20.00	SAR	الرياض	امارة منطقة الرياض	امارة منطقة الرياض	24.7136000	46.6753000	250.00	258	\N	\N	\N	[]	[]	active	f	0	2026-06-04 00:49:55.435	2026-06-04 00:49:52.429081	2026-06-04 00:49:52.429081
\.


--
-- Data for Name: rkz_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rkz_users (id, phone, name, email, authorized, auth_token, created_at) FROM stdin;
1	+966500000001	وليد العمري	waleed@rkz-demo.sa	t	31fa06be-c865-4a86-8856-4a387757c03e	2026-06-03 23:42:41.300777
2	+966599999999	Test Broker	\N	f	62b58109-fa50-4094-a023-610fa11cc1d8	2026-06-03 23:43:05.092817
4	+96611111111111	\N	\N	f	9a66385e-8ade-4049-a31d-8e3aabb899ff	2026-06-04 00:46:48.233654
3	+966111111111	\N	\N	f	3ee48fb6-30e2-4557-b734-a27389526b89	2026-06-04 00:36:23.817995
5	+966222222222	\N	\N	f	8d58e940-d269-44a8-bb8b-07d2cb790e57	2026-06-04 04:09:42.835663
6	+9661111111111	\N	\N	f	69dd7c33-0645-495a-9763-465dc4108f2c	2026-06-04 05:50:38.316279
7	+966543153957	\N	nofabark@gmail.com	f	d5ca0f84-393f-4f84-8642-e14a55bc3ec7	2026-06-04 23:25:21.144371
\.


--
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rooms (id, name, type, price_per_night, status, description, capacity, amenities, created_at, property_id, tenant_id) FROM stdin;
1	101	standard	250.00	available	\N	2	\N	2026-06-03 23:59:54.314493	1	1
2	102	deluxe	450.00	available	\N	2	\N	2026-06-03 23:59:54.314493	1	1
3	201	suite	800.00	available	\N	4	\N	2026-06-03 23:59:54.314493	1	1
4	A1	studio	320.00	available	\N	1	\N	2026-06-03 23:59:54.314493	2	1
5	A2	apartment	500.00	available	\N	3	\N	2026-06-03 23:59:54.314493	2	1
6	V1	villa	1200.00	available	\N	6	\N	2026-06-03 23:59:54.314493	3	1
\.


--
-- Data for Name: saved_searches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.saved_searches (id, tenant_id, user_id, name, criteria, notify_email, created_at) FROM stdin;
\.


--
-- Data for Name: service_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_categories (id, tenant_id, name, icon, color, property_types, is_active, sort_order, priority, requires_time_slot, created_at) FROM stdin;
1	1	Electrical	zap	yellow	all	t	1	high	f	2026-06-01 06:53:58.744634
2	1	Plumbing	droplets	blue	all	t	2	high	f	2026-06-01 06:53:58.744634
3	1	AC / Heating	wind	cyan	all	t	3	medium	f	2026-06-01 06:53:58.744634
4	1	Cleaning	brush	green	all	t	4	low	f	2026-06-01 06:53:58.744634
5	1	Maintenance	wrench	orange	all	t	5	high	f	2026-06-01 06:53:58.744634
6	1	Noise Complaint	volume-2	red	all	t	6	medium	f	2026-06-01 06:53:58.744634
7	1	Access / Keys	key	purple	compound,tower	t	7	medium	f	2026-06-01 06:53:58.744634
8	1	Internet / WiFi	wifi	indigo	all	t	8	medium	f	2026-06-01 06:53:58.744634
9	1	Parking	car	slate	compound,tower	t	9	low	f	2026-06-01 06:53:58.744634
10	1	Other	door-open	slate	all	t	10	low	f	2026-06-01 06:53:58.744634
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.settings (id, key, value, updated_at, tenant_id) FROM stdin;
1	propertyName	Grand PMS	2026-05-30 04:02:41.377305	1
2	logoText	Grand	2026-05-30 04:02:41.377305	1
3	logoSub	PMS	2026-05-30 04:02:41.377305	1
4	businessMode	hotel	2026-05-30 04:02:41.377305	1
7	contactEmail		2026-05-30 12:22:47.340205	1
8	contactPhone		2026-05-30 12:22:47.345069	1
9	contactAddress		2026-05-30 12:22:47.34774	1
10	taskTypes	[{"id":"reception","name":"Reception","color":"blue"},{"id":"housekeeping","name":"Housekeeping","color":"green"},{"id":"maintenance","name":"Maintenance","color":"orange"},{"id":"security","name":"Security","color":"red"},{"id":"general","name":"General","color":"gray"}]	2026-05-30 12:22:47.35073	1
11	taskRequirements	{"dueDate":false,"photoProof":false,"notes":false,"priority":false,"assignedTo":false}	2026-05-30 12:22:47.353123	1
12	logoUrl		2026-06-01 05:12:33.489202	1
13	navConfig	[{"id":"dashboard","order":0,"visible":true},{"id":"properties","order":1,"visible":true},{"id":"rooms","order":2,"visible":true},{"id":"unit-map","order":3,"visible":true},{"id":"maintenance","order":4,"visible":true},{"id":"facilities","order":5,"visible":true},{"id":"staff","order":6,"visible":true},{"id":"tasks","order":7,"visible":true},{"id":"guest-requests","order":8,"visible":true},{"id":"activity-log","order":9,"visible":true},{"id":"user-management","order":10,"visible":true},{"id":"admin-settings","order":11,"visible":true},{"id":"security-dashboard","order":12,"visible":true},{"id":"analytics","order":13,"visible":true},{"id":"support-tickets","order":14,"visible":true}]	2026-06-01 05:12:33.613752	1
15	primaryColor		2026-06-01 05:12:33.810559	1
16	secondaryColor		2026-06-01 05:12:33.814839	1
6	companyName	Rakez Smart Solutions	2026-06-01 20:58:17.579	1
5	enabledModules	["bookings","rooms","properties","guests","finance","maintenance","housekeeping","facilities","serviceRequests","staff","tasks","analytics","unitMap","guestRequests","activityLog","userManagement","supportTickets","serviceConfig","security"]	2026-06-01 23:06:05.115	1
14	permissionMatrix	{"admin_manager":[],"manager":[],"administrator":[],"supervisor":[],"maintenance":[],"cleaning":[],"security":[]}	2026-06-01 05:12:33.806255	1
19	portalRolePermissions	{"manager":["property:add","property:edit","marketing:listings"],"supervisor":["property:edit","marketing:listings"],"secretariat":["property:add","property:edit","support:inquiries"]}	2026-06-02 21:59:43.05852	1
23	ai_kill_switch	false	2026-06-04 20:57:56.476	1
25	rkz_analysis_killswitch	false	2026-06-06 11:15:30.685823	1
27	cms_branding	{"companyNameEn":"Rozoz Smart Solutions","companyNameAr":"روزوز للحلول الذكية","taglineEn":"Premium Property Management","taglineAr":"إدارة عقارات متميزة","logoUrl":""}	2026-06-07 13:59:26.623658	1
28	cms_about	{"titleEn":"About Rozoz Smart Solutions","titleAr":"عن روزوز للحلول الذكية","body":"Rozoz Smart Solutions is a leading property management company in Saudi Arabia.","imageUrl":""}	2026-06-07 13:59:31.448818	1
\.


--
-- Data for Name: shifts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shifts (id, staff_id, property_id, date, shift_type, start_time, end_time, notes, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: staff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.staff (id, name, role, email, phone, property_id, status, created_at, tenant_id, system_role) FROM stdin;
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.support_tickets (id, tenant_id, category, title, description, status, submitted_by_user_id, submitted_by_name, submitted_by_role, admin_notes, resolved_by_user_id, resolved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_comments (id, task_id, author_name, body, image_url, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tasks (id, title, description, category, property_id, unit_id, assigned_to_id, priority, status, due_date, completed_at, created_at, assigned_by_user_id, completed_by_user_id, proof_photo_url, tenant_id, supervisor_id, before_photo_url, after_photo_url, started_at, verified_at, verified_by_user_id, report_status, submitted_at, submitted_by_user_id, rejected_at, rejected_by_user_id, rejection_notes, escalated_at, escalated_by_user_id, approved_at, approved_by_user_id, completion_lat, completion_lng, completion_address) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenants (id, name, slug, plan, status, contact_name, contact_email, contact_phone, logo_text, logo_sub, created_at, updated_at, is_active) FROM stdin;
1	روزوز للحلول الذكية	rkz	enterprise	active	\N	\N	\N	روزوز	للحلول الذكية	2026-05-30 12:51:22.596082	2026-05-30 15:00:32.047	t
\.


--
-- Data for Name: unit_financials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.unit_financials (id, room_id, status, due_date, amount_due, check_in, check_out, updated_at, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_sessions (session_id, user_id, tenant_id, user_data, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, display_name, email, password_hash, role, permissions, is_active, created_at, must_change_password, tenant_id, phone_number, custom_role_id) FROM stdin;
3	superadmin	Nada Yousef	nada@rkz.info	$2b$12$0wi/lDZ.i.eZWuRfDa5y2.3JvpDR99WEREDZDR62quVzgUwITHKVS	super_admin	["all"]	t	2026-05-30 13:03:32.187128	t	\N	+1-555-000-0000	\N
1	admin	Administrator	admin@rkz.info	$2b$12$sVJUwPBVRDT8E6sm05GvAO8VydgWoLu9N1nhrijDitSH8MGxSXHA.	owner	["all"]	t	2026-05-29 14:59:00.507436	f	1	+1-555-000-0001	\N
16	yousef	يوسف	yousef@rkz.info	$2b$12$5SB29Zw0pLvNtL2Jbs5n/ujDmZdPrPCvVGMH7Q2Tms8JHAmWzEKTa	super_admin	[]	t	2026-06-08 07:57:34.244836	f	\N	\N	\N
5	mike.torres	Mike Torres	mike.t@grandhotel.com	ae8c78347cea26a8b91d19ea18024522e0a68b417cea1e1bdff0f1a73b6dca0d	staff	[]	t	2026-05-30 23:48:57.832281	t	1	\N	\N
6	invite.test.flow	Invite Test	invite.test.flow@example.com	$2b$12$kTODYD6V3wvRE7ueVctktuJ7g0VTj00QJ5cd3TxLsPUhDWYM0HMHm	supervisor	[]	t	2026-06-01 17:11:55.043782	t	1	\N	\N
7	verify.onboard	Verification Employee	verify.onboard@rakez-test.io	$2b$12$1NkmnVwzPMRjGiYTA/PHV.jmb7s0meXQ53N05U8L7gzkIMS5Los7m	supervisor	[]	t	2026-06-01 17:16:29.186708	t	1	\N	\N
8	alice.unique	Alice Dupont	alice.unique@rakez-test.io	$2b$12$2AG20lZutNf4B/9ksffVjeXuhhXD4wfnPWUHg6G7buMzDfCKj3mea	supervisor	[]	t	2026-06-01 17:35:06.750555	t	1	\N	\N
9	bob.first	Bob First	bob.first@rakez-test.io	$2b$12$ZSaNO1j4oQaS.70xm0hkSubHHmTy0ap4rTOhK4quLj56r.Bveswua	supervisor	[]	t	2026-06-01 17:57:22.619402	t	1	+966501234567	\N
10	no.phone1	No Phone	no.phone1@rakez-test.io	$2b$12$cEWbkjGuK5HXjRT94QlQ/eBw3GwIfQUVtRx6FhFZfkIylnjP.p2lO	supervisor	[]	t	2026-06-01 17:57:23.295691	t	1	\N	\N
11	no.phone2	No Phone 2	no.phone2@rakez-test.io	$2b$12$UAUNyNZKf44ghhPiMCKYCOahXRKEJjaPOLq0jo1z0.sDaSLrLVbDa	supervisor	[]	t	2026-06-01 17:57:23.977121	t	1	\N	\N
2	testworker	Test Worker	worker@grandpms.io	$2b$12$Hk0hNKWZ.CW8asXOywPoBuUlP7W21t5AWeaIV7kCz5hFvVWyVs3qW	maintenance	[]	t	2026-05-30 11:20:24.977783	f	1	+1-555-000-0002	\N
12	investor1	Ahmed Al-Mansouri	investor@grandpms.com	$2b$12$sVAh4Hxf2U58rFyab5RwoeGw1tALZthHs55JxBZaG/S2IDzU0y2qC	partner	[]	t	2026-06-02 10:40:47.399104	f	1	+971501234567	\N
4	sarah.collins	Sarah Collins	sarah.c@grandhotel.com	ae8c78347cea26a8b91d19ea18024522e0a68b417cea1e1bdff0f1a73b6dca0d	staff	["property:add","property:edit","marketing:campaigns","support:inquiries"]	t	2026-05-30 23:48:57.795242	t	1	\N	\N
13	testclient1	Test Client	test@example.com	$2b$12$yepOsfaUFeBPBbInY4UxY.Maz1qdzZWufRVhgs4kuM3OQurw8qgLu	client	[]	t	2026-06-02 22:40:30.484698	t	1	\N	\N
14	emailtestprobe99	Email Test User	test-email-probe@example.com	$2b$12$MwzqdWAQ2JsDxfpPgE4oq.JmGGGkxM23TlqEY04IsUQZ9wojKqMgS	client	[]	t	2026-06-04 15:28:31.131182	t	1	\N	\N
15	sendertestprobe_x7	Sender Test	test-sender-probe@mailinator.com	$2b$12$uWB1N...AYpGm7BWmUo7YO6sozB3Jr4q.z6MYxfBWJcpv9BR0jLWe	client	[]	t	2026-06-04 15:29:13.609954	t	1	\N	\N
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.webauthn_credentials (id, user_id, credential_id, public_key, counter, transports, created_at) FROM stdin;
\.


--
-- Data for Name: work_orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.work_orders (id, property_id, unit_id, title, description, priority, status, assigned_to, due_date, completed_at, created_at, cost, tenant_id, assigned_to_id) FROM stdin;
\.


--
-- Name: activity_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activity_logs_id_seq', 420, true);


--
-- Name: ai_action_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_action_queue_id_seq', 1, true);


--
-- Name: ai_audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_audit_log_id_seq', 4, true);


--
-- Name: archiving_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.archiving_logs_id_seq', 1, false);


--
-- Name: bookings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bookings_id_seq', 30, true);


--
-- Name: company_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.company_reports_id_seq', 1, false);


--
-- Name: contracts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contracts_id_seq', 5, true);


--
-- Name: conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.conversations_id_seq', 1, false);


--
-- Name: custom_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.custom_fields_id_seq', 1, false);


--
-- Name: custom_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.custom_roles_id_seq', 1, false);


--
-- Name: dividend_distributions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dividend_distributions_id_seq', 1, false);


--
-- Name: equity_stakes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.equity_stakes_id_seq', 1, false);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.expenses_id_seq', 30, true);


--
-- Name: field_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.field_users_id_seq', 1, false);


--
-- Name: guest_feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.guest_feedback_id_seq', 1, false);


--
-- Name: guest_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.guest_requests_id_seq', 2, true);


--
-- Name: guests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.guests_id_seq', 1, false);


--
-- Name: inventory_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_items_id_seq', 12, true);


--
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invoices_id_seq', 6, true);


--
-- Name: listing_inquiries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.listing_inquiries_id_seq', 1, false);


--
-- Name: listings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.listings_id_seq', 8, true);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.messages_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: portal_properties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.portal_properties_id_seq', 3, true);


--
-- Name: portal_units_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.portal_units_id_seq', 20, true);


--
-- Name: preview_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.preview_links_id_seq', 8, true);


--
-- Name: properties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.properties_id_seq', 10, true);


--
-- Name: property_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.property_categories_id_seq', 7, true);


--
-- Name: rkz_listings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rkz_listings_id_seq', 39, true);


--
-- Name: rkz_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rkz_users_id_seq', 7, true);


--
-- Name: rooms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rooms_id_seq', 20, true);


--
-- Name: saved_searches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.saved_searches_id_seq', 1, false);


--
-- Name: service_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_categories_id_seq', 10, true);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.settings_id_seq', 30, true);


--
-- Name: shifts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shifts_id_seq', 1, false);


--
-- Name: staff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.staff_id_seq', 1, false);


--
-- Name: support_tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.support_tickets_id_seq', 1, false);


--
-- Name: task_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.task_comments_id_seq', 1, false);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tasks_id_seq', 1, false);


--
-- Name: tenants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tenants_id_seq', 1, false);


--
-- Name: unit_financials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.unit_financials_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 16, true);


--
-- Name: webauthn_credentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.webauthn_credentials_id_seq', 1, false);


--
-- Name: work_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.work_orders_id_seq', 1, false);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: ai_action_queue ai_action_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_action_queue
    ADD CONSTRAINT ai_action_queue_pkey PRIMARY KEY (id);


--
-- Name: ai_audit_log ai_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_audit_log
    ADD CONSTRAINT ai_audit_log_pkey PRIMARY KEY (id);


--
-- Name: archiving_logs archiving_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.archiving_logs
    ADD CONSTRAINT archiving_logs_pkey PRIMARY KEY (id);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: company_reports company_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_reports
    ADD CONSTRAINT company_reports_pkey PRIMARY KEY (id);


--
-- Name: contracts contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: custom_fields custom_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_fields
    ADD CONSTRAINT custom_fields_pkey PRIMARY KEY (id);


--
-- Name: custom_roles custom_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_roles
    ADD CONSTRAINT custom_roles_pkey PRIMARY KEY (id);


--
-- Name: dividend_distributions dividend_distributions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dividend_distributions
    ADD CONSTRAINT dividend_distributions_pkey PRIMARY KEY (id);


--
-- Name: equity_stakes equity_stakes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equity_stakes
    ADD CONSTRAINT equity_stakes_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: field_users field_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.field_users
    ADD CONSTRAINT field_users_pkey PRIMARY KEY (id);


--
-- Name: guest_feedback guest_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guest_feedback
    ADD CONSTRAINT guest_feedback_pkey PRIMARY KEY (id);


--
-- Name: guest_requests guest_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guest_requests
    ADD CONSTRAINT guest_requests_pkey PRIMARY KEY (id);


--
-- Name: guests guests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guests
    ADD CONSTRAINT guests_pkey PRIMARY KEY (id);


--
-- Name: guests guests_tenant_id_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guests
    ADD CONSTRAINT guests_tenant_id_email_key UNIQUE (tenant_id, email);


--
-- Name: inventory_items inventory_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: listing_inquiries listing_inquiries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listing_inquiries
    ADD CONSTRAINT listing_inquiries_pkey PRIMARY KEY (id);


--
-- Name: listings listings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listings
    ADD CONSTRAINT listings_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: portal_properties portal_properties_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.portal_properties
    ADD CONSTRAINT portal_properties_pkey PRIMARY KEY (id);


--
-- Name: portal_units portal_units_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.portal_units
    ADD CONSTRAINT portal_units_pkey PRIMARY KEY (id);


--
-- Name: preview_links preview_links_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preview_links
    ADD CONSTRAINT preview_links_pkey PRIMARY KEY (id);


--
-- Name: preview_links preview_links_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preview_links
    ADD CONSTRAINT preview_links_token_key UNIQUE (token);


--
-- Name: properties properties_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_pkey PRIMARY KEY (id);


--
-- Name: property_categories property_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.property_categories
    ADD CONSTRAINT property_categories_pkey PRIMARY KEY (id);


--
-- Name: rkz_listings rkz_listings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rkz_listings
    ADD CONSTRAINT rkz_listings_pkey PRIMARY KEY (id);


--
-- Name: rkz_users rkz_users_phone_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rkz_users
    ADD CONSTRAINT rkz_users_phone_key UNIQUE (phone);


--
-- Name: rkz_users rkz_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rkz_users
    ADD CONSTRAINT rkz_users_pkey PRIMARY KEY (id);


--
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (id);


--
-- Name: saved_searches saved_searches_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saved_searches
    ADD CONSTRAINT saved_searches_pkey PRIMARY KEY (id);


--
-- Name: service_categories service_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_categories
    ADD CONSTRAINT service_categories_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: settings settings_tenant_key_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_tenant_key_uniq UNIQUE (tenant_id, key);


--
-- Name: shifts shifts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shifts
    ADD CONSTRAINT shifts_pkey PRIMARY KEY (id);


--
-- Name: staff staff_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: task_comments task_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_slug_key UNIQUE (slug);


--
-- Name: tenants tenants_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_slug_unique UNIQUE (slug);


--
-- Name: unit_financials unit_financials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.unit_financials
    ADD CONSTRAINT unit_financials_pkey PRIMARY KEY (id);


--
-- Name: unit_financials unit_financials_room_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.unit_financials
    ADD CONSTRAINT unit_financials_room_id_key UNIQUE (room_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (session_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: webauthn_credentials webauthn_credentials_credential_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_credential_id_key UNIQUE (credential_id);


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_pkey PRIMARY KEY (id);


--
-- Name: work_orders work_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.work_orders
    ADD CONSTRAINT work_orders_pkey PRIMARY KEY (id);


--
-- Name: ai_action_queue_tenant_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ai_action_queue_tenant_status_idx ON public.ai_action_queue USING btree (tenant_id, status);


--
-- Name: ai_audit_log_queue_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ai_audit_log_queue_idx ON public.ai_audit_log USING btree (action_queue_id);


--
-- Name: ai_audit_log_tenant_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ai_audit_log_tenant_idx ON public.ai_audit_log USING btree (tenant_id, created_at DESC);


--
-- Name: bookings_tenant_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bookings_tenant_status_idx ON public.bookings USING btree (tenant_id, status);


--
-- Name: listing_inquiries_listing; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX listing_inquiries_listing ON public.listing_inquiries USING btree (listing_id);


--
-- Name: listings_featured; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX listings_featured ON public.listings USING btree (featured) WHERE (featured = true);


--
-- Name: listings_tenant_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX listings_tenant_status ON public.listings USING btree (tenant_id, status);


--
-- Name: notifications_tenant_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_tenant_idx ON public.notifications USING btree (tenant_id);


--
-- Name: notifications_tenant_unread_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_tenant_unread_idx ON public.notifications USING btree (tenant_id, is_read, created_at DESC);


--
-- Name: notifications_tenant_user_unread_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_tenant_user_unread_idx ON public.notifications USING btree (tenant_id, user_id, is_read, created_at DESC);


--
-- Name: preview_links_token_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX preview_links_token_idx ON public.preview_links USING btree (token);


--
-- Name: staff_email_tenant_uniq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX staff_email_tenant_uniq ON public.staff USING btree (tenant_id, email);


--
-- Name: staff_phone_tenant_uniq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX staff_phone_tenant_uniq ON public.staff USING btree (tenant_id, phone) WHERE ((phone IS NOT NULL) AND (phone <> ''::text));


--
-- Name: staff_tenant_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX staff_tenant_idx ON public.staff USING btree (tenant_id);


--
-- Name: tasks_due_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tasks_due_date_idx ON public.tasks USING btree (due_date);


--
-- Name: tasks_tenant_assignee_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tasks_tenant_assignee_idx ON public.tasks USING btree (tenant_id, assigned_to_id);


--
-- Name: tasks_tenant_property_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tasks_tenant_property_idx ON public.tasks USING btree (tenant_id, property_id);


--
-- Name: tasks_tenant_report_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tasks_tenant_report_status_idx ON public.tasks USING btree (tenant_id, report_status);


--
-- Name: tasks_tenant_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tasks_tenant_status_idx ON public.tasks USING btree (tenant_id, status);


--
-- Name: tasks_tenant_supervisor_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tasks_tenant_supervisor_idx ON public.tasks USING btree (tenant_id, supervisor_id);


--
-- Name: user_sessions_expires_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_sessions_expires_idx ON public.user_sessions USING btree (expires_at);


--
-- Name: user_sessions_tenant_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_sessions_tenant_idx ON public.user_sessions USING btree (tenant_id);


--
-- Name: user_sessions_user_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_sessions_user_idx ON public.user_sessions USING btree (user_id);


--
-- Name: users_email_tenant_uniq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_email_tenant_uniq ON public.users USING btree (tenant_id, email) WHERE ((tenant_id IS NOT NULL) AND (email IS NOT NULL));


--
-- Name: users_phone_tenant_uniq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_phone_tenant_uniq ON public.users USING btree (tenant_id, phone_number) WHERE ((phone_number IS NOT NULL) AND (phone_number <> ''::text) AND (tenant_id IS NOT NULL));


--
-- Name: users_tenant_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_tenant_idx ON public.users USING btree (tenant_id);


--
-- Name: webauthn_creds_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX webauthn_creds_user_id ON public.webauthn_credentials USING btree (user_id);


--
-- Name: work_orders_tenant_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX work_orders_tenant_status_idx ON public.work_orders USING btree (tenant_id, status);


--
-- Name: messages messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: portal_units portal_units_portal_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.portal_units
    ADD CONSTRAINT portal_units_portal_property_id_fkey FOREIGN KEY (portal_property_id) REFERENCES public.portal_properties(id) ON DELETE CASCADE;


--
-- Name: task_comments task_comments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict nhgXYfPSaiH5dSFDoCrQrNkXsgXm2iThbYzzhODFM6mZLNU7mONgwmd4P4v1icG

