# RKZ — Standalone Mobile App (100% Offline Build)

## What changed
This package is fully decoupled from any server or web portal.
Every feature runs locally on the device — no network calls are made.

| Feature | How it works now |
|---|---|
| Login | Any phone number + any 6-digit OTP works — no server needed |
| Property listings | Stored in AsyncStorage on device |
| AI price suggestion | Local algorithm using property type, city, and area |
| AI description | Local template generator |
| AI chat assistant | Local rule-based engine (Arabic + English) |
| Portfolio report | Generated from on-device data |
| Lead qualification | Local scoring engine |
| Investor portal | Built-in credentials: admin / admin123 |
| Admin PIN | Default PIN: 1234 |
| App config | Saved to AsyncStorage — no remote fetch |

## Prerequisites (one-time)
- Node.js 18+
- Expo account (free at https://expo.dev)

## Build the APK (15 minutes)

Step 1 — Install EAS CLI:
  npm install -g eas-cli

Step 2 — Log in to Expo:
  eas login

Step 3 — Install dependencies (from this folder):
  npm install

Step 4 — Build:
  eas build --platform android --profile preview

EAS uploads the code to Expo's servers and emails/displays a .apk download link.

## App details
- Package: com.rkz.app
- Build type: APK (direct install, no Play Store needed)
- Distribution: internal
