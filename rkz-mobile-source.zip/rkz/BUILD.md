# RKZ Mobile App — Build Instructions for Developer

## What this is
Complete React Native (Expo) source code for the RKZ mobile app.
Backend API is already live at: https://property-dashboard-nofabark.replit.app

## Prerequisites (one-time setup)
- Node.js 18+ installed
- An Expo account (free at https://expo.dev)

## Steps to produce the APK (15 minutes total)

### 1. Install EAS CLI
```
npm install -g eas-cli
```

### 2. Log in to Expo
```
eas login
```

### 3. Install dependencies
```
npm install
```

### 4. Build the APK
```
eas build --platform android --profile preview
```

EAS will upload the code to Expo's servers and return a download link for the .apk file when done (~10-15 min).

## Configuration — already done, do not change
- `eas.json` — build profile configured, APK type set, API domain embedded
- `app.json` — bundle ID `com.rkz.app`, origin set to live server
- `EXPO_PUBLIC_DOMAIN` — baked into eas.json env, points to live backend

## Live backend URL
https://property-dashboard-nofabark.replit.app

## Notes
- The app connects to the live backend automatically — no local server needed
- Dev mode bypass is active; login screen is skipped in development
- For production builds use: `eas build --platform android --profile production`
