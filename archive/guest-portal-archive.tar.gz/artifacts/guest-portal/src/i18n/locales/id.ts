import type { Translations } from "./en";

const id: Translations = {
  request: {
    serviceRequest: "Permintaan Layanan",
    requestType: "Jenis Permintaan",
    description: "Deskripsi",
    descPlaceholder: "Jelaskan masalah secara singkat…",
    submit: "Kirim Permintaan",
    submitting: "Mengirim...",
    unitNotFound: "Unit tidak ditemukan",
    invalidUnit: "Masukkan nomor unit yang valid.",
    errorGeneric: "Terjadi kesalahan. Silakan coba lagi.",
    types: {
      electrical: "Kelistrikan",
      plumbing: "Pipa/Saluran",
      ac: "AC / Pemanas",
      cleaning: "Kebersihan",
      maintenance: "Pemeliharaan",
      noise: "Kebisingan",
      other: "Lainnya",
    },
    timeSlot: "Slot Waktu yang Diinginkan",
    timeSlotPlaceholder: "Pilih jendela waktu",
    timeSlotHint: "Harap berada di tempat selama jendela waktu yang dipilih agar tim kami dapat membantu Anda.",
    success: {
      title: "Permintaan Diterima",
      subtitle: "Permintaan Anda telah diterima.",
      refCode: "Kode Referensi",
      keepCode: "Simpan kode referensi Anda untuk tindak lanjut",
      newRequest: "Permintaan Baru",
    },
    status: { label: "Status Permintaan", pending: "Menunggu", hint: "Diperbarui otomatis setiap 30 detik" },
    rating: { title: "Nilai Pengalaman Anda", subtitle: "Bagaimana layanan kami?", commentPlaceholder: "Tinggalkan komentar (opsional)…", submit: "Kirim Penilaian", thankyou: "Terima kasih atas masukan Anda!" },
  },
  landing: {
    accessUnit: "Akses Unit Anda",
    enterUnit: "Masukkan nomor unit Anda untuk memulai",
    accessPortal: "Akses Portal",
    submitRequests: "Kirim Permintaan",
    rateStay: "Nilai Masa Inap Anda",
    unitDetails: "Detail Unit",
  },
  lang: { select: "Bahasa" },
};

export default id;
