const en = {
  request: {
    serviceRequest: "Service Request",
    requestType: "Request Type",
    description: "Description",
    descPlaceholder: "Briefly describe the issue…",
    submit: "Submit Request",
    submitting: "Submitting...",
    unitNotFound: "Unit not found",
    invalidUnit: "Please enter a valid unit number.",
    errorGeneric: "An error occurred. Please try again.",
    types: {
      electrical: "Electrical",
      plumbing: "Plumbing",
      ac: "AC / Heating",
      cleaning: "Cleaning",
      maintenance: "Maintenance",
      noise: "Noise",
      other: "Other",
    },
    timeSlot: "Preferred Time Slot",
    timeSlotPlaceholder: "Select a time window",
    timeSlotHint: "Please be present during the selected window for our team to assist you.",
    success: {
      title: "Request Received",
      subtitle: "Your request has been received.",
      refCode: "Reference Code",
      keepCode: "Keep your reference code for follow-up",
      newRequest: "New Request",
    },
    status: {
      label: "Request Status",
      pending: "Pending",
      hint: "Auto-refreshes every 30 seconds",
    },
    rating: {
      title: "Rate Your Experience",
      subtitle: "How was our service?",
      commentPlaceholder: "Leave a comment (optional)…",
      submit: "Submit Rating",
      thankyou: "Thank you for your feedback!",
    },
  },
  landing: {
    accessUnit: "Access Your Unit",
    enterUnit: "Enter your unit number to get started",
    accessPortal: "Access Portal",
    submitRequests: "Submit Requests",
    rateStay: "Rate Your Stay",
    unitDetails: "Unit Details",
  },
  lang: { select: "Language" },
};

export type Translations = typeof en;
export default en;
